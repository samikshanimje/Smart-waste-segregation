import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Landing from "./pages/Landing";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";

import AdminLayout from "./components/layouts/AdminLayout";
import AdminDashboard from "./pages/admin/Dashboard";
import AdminLiveFeed from "./pages/admin/LiveFeed";
import AdminBins from "./pages/admin/Bins";
import AdminAlerts from "./pages/admin/Alerts";
import AdminAnalytics from "./pages/admin/Analytics";
import AdminLogs from "./pages/admin/Logs";
import AdminNgos from "./pages/admin/NgosManagement";
import AdminCitizens from "./pages/admin/Citizens";
import AdminShop from "./pages/admin/ShopAdmin";
import AdminSettings from "./pages/admin/Settings";

import CitizenLayout from "./components/layouts/CitizenLayout";
import CitizenDashboard from "./pages/citizen/Dashboard";
import NfcTap from "./pages/citizen/NfcTap";
import CitizenFeed from "./pages/citizen/Feed";
import Wallet from "./pages/citizen/Wallet";
import Shop from "./pages/citizen/Shop";
import Achievements from "./pages/citizen/Achievements";
import LeaderboardPage from "./pages/citizen/Leaderboard";
import NgosView from "./pages/citizen/NgosView";
import CitizenProfile from "./pages/citizen/Profile";

import NgoLayout from "./components/layouts/NgoLayout";
import NgoDashboard from "./pages/ngo/Dashboard";
import NgoRequests from "./pages/ngo/Requests";
import NgoHistory from "./pages/ngo/History";
import NgoNotifications from "./pages/ngo/Notifications";
import NgoProfile from "./pages/ngo/NgoProfile";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/login" element={<Login />} />

          <Route path="/admin" element={<AdminLayout />}>
            <Route path="dashboard" element={<AdminDashboard />} />
            <Route path="live-feed" element={<AdminLiveFeed />} />
            <Route path="bins" element={<AdminBins />} />
            <Route path="alerts" element={<AdminAlerts />} />
            <Route path="analytics" element={<AdminAnalytics />} />
            <Route path="logs" element={<AdminLogs />} />
            <Route path="ngos" element={<AdminNgos />} />
            <Route path="citizens" element={<AdminCitizens />} />
            <Route path="shop" element={<AdminShop />} />
            <Route path="settings" element={<AdminSettings />} />
          </Route>

          <Route path="/citizen" element={<CitizenLayout />}>
            <Route path="dashboard" element={<CitizenDashboard />} />
            <Route path="nfc" element={<NfcTap />} />
            <Route path="feed" element={<CitizenFeed />} />
            <Route path="wallet" element={<Wallet />} />
            <Route path="shop" element={<Shop />} />
            <Route path="achievements" element={<Achievements />} />
            <Route path="leaderboard" element={<LeaderboardPage />} />
            <Route path="ngos" element={<NgosView />} />
            <Route path="profile" element={<CitizenProfile />} />
          </Route>

          <Route path="/ngo" element={<NgoLayout />}>
            <Route path="dashboard" element={<NgoDashboard />} />
            <Route path="requests" element={<NgoRequests />} />
            <Route path="history" element={<NgoHistory />} />
            <Route path="notifications" element={<NgoNotifications />} />
            <Route path="profile" element={<NgoProfile />} />
          </Route>

          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
