import { NavLink, Outlet } from 'react-router-dom';
import { Recycle, LayoutDashboard, ClipboardList, History, Bell, Building2, LogOut } from 'lucide-react';

const navItems = [
  { to: '/ngo/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/ngo/requests', icon: ClipboardList, label: 'My Requests' },
  { to: '/ngo/history', icon: History, label: 'History' },
  { to: '/ngo/notifications', icon: Bell, label: 'Notifications' },
  { to: '/ngo/profile', icon: Building2, label: 'Profile' },
];

export default function NgoLayout() {
  return (
    <div className="flex min-h-screen w-full">
      <aside className="hidden lg:flex flex-col w-52 bg-card border-r border-border fixed inset-y-0 left-0 z-40">
        <div className="p-4 border-b border-border">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-green-500 flex items-center justify-center"><Recycle className="w-5 h-5 text-primary-foreground" /></div>
            <div>
              <span className="text-sm font-bold text-green-700">SwachhSmart</span>
              <p className="text-[10px] text-muted-foreground">NGO Portal</p>
            </div>
          </div>
        </div>
        <div className="px-4 py-3 border-b border-border">
          <p className="text-xs font-semibold text-foreground">GreenEarth Foundation</p>
          <span className="text-[10px] bg-green-100 text-green-700 rounded-full px-2 py-0.5 font-semibold">✓ Approved</span>
        </div>
        <nav className="flex-1 py-2">
          {navItems.map(item => (
            <NavLink key={item.to} to={item.to}
              className={({ isActive }) => `flex items-center gap-3 mx-2 my-0.5 px-3 py-2.5 rounded-xl text-sm transition-colors ${isActive ? 'bg-green-100 text-green-700 font-semibold' : 'text-sidebar-foreground hover:bg-background'}`}>
              <item.icon className="w-4 h-4" />{item.label}
            </NavLink>
          ))}
        </nav>
        <div className="p-4 border-t border-border">
          <NavLink to="/login" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"><LogOut className="w-4 h-4" />Sign Out</NavLink>
        </div>
      </aside>
      <main className="flex-1 lg:ml-52 bg-background min-h-screen pb-20 lg:pb-0">
        <div className="lg:hidden flex items-center gap-2 p-4 bg-card border-b border-border">
          <Recycle className="w-5 h-5 text-green-500" />
          <span className="font-bold text-green-700 text-sm">SwachhSmart NGO</span>
        </div>
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6"><Outlet /></div>
        <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-card border-t border-border flex justify-around py-2 z-40">
          {navItems.map(item => (
            <NavLink key={item.to} to={item.to}
              className={({ isActive }) => `flex flex-col items-center gap-1 text-[10px] ${isActive ? 'text-green-700' : 'text-muted-foreground'}`}>
              <item.icon className="w-5 h-5" />{item.label}
            </NavLink>
          ))}
        </div>
      </main>
    </div>
  );
}
