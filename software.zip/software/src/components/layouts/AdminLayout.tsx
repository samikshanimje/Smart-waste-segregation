import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { Recycle, LayoutDashboard, Radio, Trash2, AlertTriangle, BarChart3, FileText, Users, Building2, ShoppingBag, Settings, LogOut } from 'lucide-react';

const navItems = [
  { to: '/admin/dashboard', icon: LayoutDashboard, label: 'Overview' },
  { to: '/admin/live-feed', icon: Radio, label: 'Live Feed' },
  { to: '/admin/bins', icon: Trash2, label: 'Bins' },
  { to: '/admin/alerts', icon: AlertTriangle, label: 'Alerts' },
  { to: '/admin/analytics', icon: BarChart3, label: 'Analytics' },
  { to: '/admin/logs', icon: FileText, label: 'Logs' },
  { to: '/admin/ngos', icon: Building2, label: 'NGOs' },
  { to: '/admin/citizens', icon: Users, label: 'Citizens' },
  { to: '/admin/shop', icon: ShoppingBag, label: 'SwachhMart' },
  { to: '/admin/settings', icon: Settings, label: 'Settings' },
];

export default function AdminLayout() {
  const location = useLocation();
  return (
    <div className="flex min-h-screen w-full">
      <aside className="hidden lg:flex flex-col w-56 bg-card border-r border-border fixed inset-y-0 left-0 z-40">
        <div className="p-4 border-b border-border">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-green-500 flex items-center justify-center">
              <Recycle className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <span className="text-sm font-bold text-green-700">SwachhSmart</span>
              <p className="text-[10px] text-muted-foreground">Admin Panel</p>
            </div>
          </div>
        </div>
        <nav className="flex-1 py-2 overflow-y-auto">
          {navItems.map(item => (
            <NavLink key={item.to} to={item.to}
              className={({ isActive }) => `flex items-center gap-3 mx-2 my-0.5 px-3 py-2.5 rounded-xl text-sm transition-colors ${isActive ? 'bg-green-100 text-green-700 font-semibold' : 'text-sidebar-foreground hover:bg-background'}`}>
              <item.icon className="w-4 h-4" />{item.label}
            </NavLink>
          ))}
        </nav>
        <div className="p-4 border-t border-border">
          <NavLink to="/login" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
            <LogOut className="w-4 h-4" />Sign Out
          </NavLink>
        </div>
      </aside>
      <main className="flex-1 lg:ml-56 bg-background min-h-screen">
        <div className="lg:hidden flex items-center gap-2 p-4 bg-card border-b border-border">
          <Recycle className="w-5 h-5 text-green-500" />
          <span className="font-bold text-green-700 text-sm">SwachhSmart Admin</span>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
          <Outlet />
        </div>
        <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-card border-t border-border flex justify-around py-2 z-40">
          {navItems.slice(0, 5).map(item => (
            <NavLink key={item.to} to={item.to}
              className={({ isActive }) => `flex flex-col items-center gap-1 text-[10px] ${isActive ? 'text-green-700' : 'text-muted-foreground'}`}>
              <item.icon className="w-5 h-5" />{item.label}
            </NavLink>
          ))}
        </div>
      </main>
    </div>
  );
}
