import { NavLink, Outlet } from 'react-router-dom';
import { Recycle, Home, Zap, Radio, Wallet, ShoppingBag, Trophy, Medal, Building2, User, LogOut } from 'lucide-react';

const sidebarItems = [
  { to: '/citizen/dashboard', icon: Home, label: 'Home' },
  { to: '/citizen/nfc', icon: Zap, label: 'Tap NFC' },
  { to: '/citizen/feed', icon: Radio, label: 'Live Feed' },
  { to: '/citizen/wallet', icon: Wallet, label: 'Wallet' },
  { to: '/citizen/shop', icon: ShoppingBag, label: 'Shop' },
  { to: '/citizen/achievements', icon: Trophy, label: 'Badges' },
  { to: '/citizen/leaderboard', icon: Medal, label: 'Leaderboard' },
  { to: '/citizen/ngos', icon: Building2, label: 'NGOs' },
  { to: '/citizen/profile', icon: User, label: 'Profile' },
];

const bottomNav = [
  { to: '/citizen/dashboard', icon: Home, label: 'Home' },
  { to: '/citizen/nfc', icon: Zap, label: 'Tap NFC' },
  { to: '/citizen/shop', icon: ShoppingBag, label: 'Shop' },
  { to: '/citizen/achievements', icon: Trophy, label: 'Badges' },
  { to: '/citizen/profile', icon: User, label: 'Profile' },
];

export default function CitizenLayout() {
  return (
    <div className="flex min-h-screen w-full">
      <aside className="hidden lg:flex flex-col w-60 bg-card border-r border-border fixed inset-y-0 left-0 z-40">
        <div className="p-4 border-b border-border">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-green-500 flex items-center justify-center"><Recycle className="w-5 h-5 text-primary-foreground" /></div>
            <span className="text-sm font-bold text-green-700">SwachhSmart</span>
          </div>
        </div>
        <nav className="flex-1 py-2 overflow-y-auto">
          {sidebarItems.map(item => (
            <NavLink key={item.to} to={item.to}
              className={({ isActive }) => `flex items-center gap-3 mx-2 my-0.5 px-3 py-2.5 rounded-xl text-sm transition-colors ${isActive ? 'bg-green-100 text-green-700 font-semibold' : 'text-sidebar-foreground hover:bg-background'}`}>
              <item.icon className="w-4 h-4" />{item.label}
            </NavLink>
          ))}
        </nav>
        <div className="p-4 border-t border-border">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-green-500 to-green-300 flex items-center justify-center text-primary-foreground font-bold text-sm">PS</div>
            <div>
              <p className="text-sm font-semibold text-foreground">Priya Sharma</p>
              <p className="text-xs text-xpgold font-bold">🪙 2,450</p>
            </div>
          </div>
          <NavLink to="/login" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
            <LogOut className="w-4 h-4" />Sign Out
          </NavLink>
        </div>
      </aside>
      <main className="flex-1 lg:ml-60 bg-background min-h-screen pb-20 lg:pb-0">
        <div className="lg:hidden flex items-center justify-between p-4 bg-card border-b border-border">
          <div className="flex items-center gap-2">
            <Recycle className="w-5 h-5 text-green-500" />
            <span className="font-bold text-green-700 text-sm">SwachhSmart</span>
          </div>
          <span className="bg-saffron-100 text-saffron-500 rounded-full px-3 py-1 text-xs font-bold">🪙 2,450</span>
        </div>
        <div className="max-w-5xl mx-auto px-4 py-6"><Outlet /></div>
        <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-card border-t border-border flex justify-around py-2 z-40">
          {bottomNav.map(item => (
            <NavLink key={item.to} to={item.to}
              className={({ isActive }) => `flex flex-col items-center gap-1 text-[10px] ${isActive ? 'text-green-700' : 'text-muted-foreground'}`}>
              <item.icon className="w-5 h-5" />{item.label}
            </NavLink>
          ))}
        </div>
      </main>
    </div>
  );
}
