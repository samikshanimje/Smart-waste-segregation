export const bins = [
  { id: '1', bin_code: 'BIN-042', location_name: 'Sector 15', address: 'Near Metro Station, Sector 15, Noida', lat: 28.585, lng: 77.31, zone: 'Noida', ward: 'Ward 5', fill_level: 72, status: 'active', last_emptied: '2026-02-23T08:00:00Z', light_intensity: 80, lock_enabled: true, is_locked: false },
  { id: '2', bin_code: 'BIN-015', location_name: 'MG Road', address: 'MG Road Metro Exit, Bangalore', lat: 12.975, lng: 77.607, zone: 'Bangalore', ward: 'Ward 12', fill_level: 91, status: 'active', last_emptied: '2026-02-22T14:00:00Z', light_intensity: 60, lock_enabled: false, is_locked: false },
  { id: '3', bin_code: 'BIN-108', location_name: 'Connaught Place', address: 'Block A, CP, New Delhi', lat: 28.632, lng: 77.219, zone: 'Delhi', ward: 'Ward 1', fill_level: 45, status: 'active', last_emptied: '2026-02-24T06:00:00Z', light_intensity: 90, lock_enabled: true, is_locked: false },
  { id: '4', bin_code: 'BIN-067', location_name: 'Marine Drive', address: 'Marine Drive Promenade, Mumbai', lat: 18.944, lng: 72.823, zone: 'Mumbai', ward: 'Ward 8', fill_level: 88, status: 'active', last_emptied: '2026-02-21T10:00:00Z', light_intensity: 75, lock_enabled: false, is_locked: false },
  { id: '5', bin_code: 'BIN-023', location_name: 'Koregaon Park', address: 'Lane 6, Koregaon Park, Pune', lat: 18.536, lng: 73.893, zone: 'Pune', ward: 'Ward 3', fill_level: 33, status: 'active', last_emptied: '2026-02-24T07:30:00Z', light_intensity: 85, lock_enabled: true, is_locked: false },
  { id: '6', bin_code: 'BIN-091', location_name: 'Rajpath', address: 'Near India Gate, New Delhi', lat: 28.613, lng: 77.229, zone: 'Delhi', ward: 'Ward 1', fill_level: 56, status: 'active', last_emptied: '2026-02-23T16:00:00Z', light_intensity: 70, lock_enabled: false, is_locked: false },
  { id: '7', bin_code: 'BIN-033', location_name: 'Indiranagar', address: '100ft Road, Indiranagar, Bangalore', lat: 12.978, lng: 77.641, zone: 'Bangalore', ward: 'Ward 14', fill_level: 97, status: 'active', last_emptied: '2026-02-20T12:00:00Z', light_intensity: 50, lock_enabled: true, is_locked: true },
  { id: '8', bin_code: 'BIN-054', location_name: 'Bandra West', address: 'Hill Road, Bandra West, Mumbai', lat: 19.054, lng: 72.836, zone: 'Mumbai', ward: 'Ward 10', fill_level: 15, status: 'active', last_emptied: '2026-02-24T05:00:00Z', light_intensity: 95, lock_enabled: false, is_locked: false },
];

export const users = [
  { id: '1', name: 'Priya Sharma', phone: '9876543210', ward: 'Ward 5', zone: 'Noida', points: 2450, level: 3, streak: 7, avatar_url: null },
  { id: '2', name: 'Arjun Mehta', phone: '9876543211', ward: 'Ward 12', zone: 'Bangalore', points: 4200, level: 5, streak: 14, avatar_url: null },
  { id: '3', name: 'Kavya Nair', phone: '9876543212', ward: 'Ward 1', zone: 'Delhi', points: 1850, level: 3, streak: 3, avatar_url: null },
  { id: '4', name: 'Rohan Gupta', phone: '9876543213', ward: 'Ward 8', zone: 'Mumbai', points: 3100, level: 4, streak: 21, avatar_url: null },
  { id: '5', name: 'Anjali Singh', phone: '9876543214', ward: 'Ward 3', zone: 'Pune', points: 890, level: 2, streak: 5, avatar_url: null },
  { id: '6', name: 'Vikram Patel', phone: '9876543215', ward: 'Ward 5', zone: 'Noida', points: 5100, level: 6, streak: 30, avatar_url: null },
  { id: '7', name: 'Sneha Reddy', phone: '9876543216', ward: 'Ward 14', zone: 'Bangalore', points: 670, level: 2, streak: 2, avatar_url: null },
  { id: '8', name: 'Amit Kumar', phone: '9876543217', ward: 'Ward 1', zone: 'Delhi', points: 1200, level: 3, streak: 0, avatar_url: null },
  { id: '9', name: 'Divya Joshi', phone: '9876543218', ward: 'Ward 10', zone: 'Mumbai', points: 3800, level: 5, streak: 11, avatar_url: null },
  { id: '10', name: 'Rahul Verma', phone: '9876543219', ward: 'Ward 3', zone: 'Pune', points: 450, level: 1, streak: 1, avatar_url: null },
];

export type Category = 'plastic' | 'paper' | 'metal' | 'organic' | 'e-waste';

export const categoryColors: Record<Category, string> = {
  plastic: 'bg-cat-plastic',
  paper: 'bg-cat-paper',
  metal: 'bg-cat-metal',
  organic: 'bg-cat-organic',
  'e-waste': 'bg-cat-ewaste',
};

export const categoryTextColors: Record<Category, string> = {
  plastic: 'text-cat-plastic',
  paper: 'text-cat-paper',
  metal: 'text-cat-metal',
  organic: 'text-cat-organic',
  'e-waste': 'text-cat-ewaste',
};

export const classifications = [
  { id: '1', bin_id: '1', bin_code: 'BIN-042', user_id: '1', category: 'plastic' as Category, confidence: 96, is_contamination: false, timestamp: '2026-02-24T09:42:00Z', points: 20 },
  { id: '2', bin_id: '3', bin_code: 'BIN-108', user_id: '3', category: 'organic' as Category, confidence: 89, is_contamination: false, timestamp: '2026-02-24T09:38:00Z', points: 10 },
  { id: '3', bin_id: '2', bin_code: 'BIN-015', user_id: '2', category: 'metal' as Category, confidence: 94, is_contamination: false, timestamp: '2026-02-24T09:35:00Z', points: 30 },
  { id: '4', bin_id: '4', bin_code: 'BIN-067', user_id: '4', category: 'paper' as Category, confidence: 91, is_contamination: false, timestamp: '2026-02-24T09:30:00Z', points: 15 },
  { id: '5', bin_id: '1', bin_code: 'BIN-042', user_id: '5', category: 'e-waste' as Category, confidence: 87, is_contamination: true, timestamp: '2026-02-24T09:25:00Z', points: 0 },
  { id: '6', bin_id: '5', bin_code: 'BIN-023', user_id: '1', category: 'plastic' as Category, confidence: 98, is_contamination: false, timestamp: '2026-02-24T09:20:00Z', points: 20 },
  { id: '7', bin_id: '6', bin_code: 'BIN-091', user_id: '6', category: 'organic' as Category, confidence: 92, is_contamination: false, timestamp: '2026-02-24T09:15:00Z', points: 10 },
  { id: '8', bin_id: '3', bin_code: 'BIN-108', user_id: '8', category: 'metal' as Category, confidence: 85, is_contamination: true, timestamp: '2026-02-24T09:10:00Z', points: 0 },
  { id: '9', bin_id: '7', bin_code: 'BIN-033', user_id: '2', category: 'paper' as Category, confidence: 93, is_contamination: false, timestamp: '2026-02-24T09:05:00Z', points: 15 },
  { id: '10', bin_id: '8', bin_code: 'BIN-054', user_id: '9', category: 'plastic' as Category, confidence: 97, is_contamination: false, timestamp: '2026-02-24T09:00:00Z', points: 20 },
];

export const products = [
  { id: '1', name: 'Recycled Notebook', description: 'Made from 100% recycled paper. Perfect for everyday notes.', coin_price: 80, stock: 45, category: 'Stationery', eco_impact_kg: 0.3 },
  { id: '2', name: 'Jute Tote Bag', description: 'Handcrafted jute bag. Say no to plastic bags!', coin_price: 150, stock: 30, category: 'Bags', eco_impact_kg: 0.8 },
  { id: '3', name: 'Seed Starter Kit', description: 'Grow your own herbs at home with organic seeds.', coin_price: 200, stock: 20, category: 'Garden', eco_impact_kg: 1.2 },
  { id: '4', name: 'Bamboo Water Bottle', description: 'Sustainable bamboo bottle. Keeps drinks cool for 12 hours.', coin_price: 350, stock: 15, category: 'Lifestyle', eco_impact_kg: 2.5 },
  { id: '5', name: 'Home Compost Bin', description: 'Start composting kitchen waste at home easily.', coin_price: 500, stock: 10, category: 'Kitchen', eco_impact_kg: 5.0 },
  { id: '6', name: 'Eco Pen Set', description: 'Set of 5 pens made from recycled materials.', coin_price: 60, stock: 60, category: 'Stationery', eco_impact_kg: 0.1 },
  { id: '7', name: 'Cotton Shopping Bag', description: 'Organic cotton bag with SwachhSmart branding.', coin_price: 120, stock: 25, category: 'Bags', eco_impact_kg: 0.6 },
  { id: '8', name: 'Plant Grow Kit', description: 'Indoor plant kit with pot, soil, and seeds.', coin_price: 280, stock: 12, category: 'Garden', eco_impact_kg: 1.8 },
  { id: '9', name: 'Steel Straw Set', description: 'Reusable stainless steel straws with cleaning brush.', coin_price: 100, stock: 40, category: 'Kitchen', eco_impact_kg: 0.4 },
  { id: '10', name: 'Recycled Coaster Set', description: 'Set of 4 coasters made from recycled rubber.', coin_price: 90, stock: 35, category: 'Lifestyle', eco_impact_kg: 0.5 },
];

export const ngos = [
  { id: '1', org_name: 'GreenEarth Foundation', reg_number: 'NGO-2024-001', contact_name: 'Meera Iyer', phone: '9800000001', email: 'contact@greenearth.org', zones_served: ['Noida', 'Delhi'], waste_types_accepted: ['Plastic', 'Paper', 'Metal'], approved: true, total_pickups: 124, total_kg: 892 },
  { id: '2', org_name: 'RecycleBharat', reg_number: 'NGO-2024-002', contact_name: 'Sanjay Deshmukh', phone: '9800000002', email: 'info@recyclebharat.in', zones_served: ['Mumbai', 'Pune'], waste_types_accepted: ['Plastic', 'Metal', 'E-Waste'], approved: true, total_pickups: 89, total_kg: 634 },
  { id: '3', org_name: 'EcoSeva India', reg_number: 'NGO-2024-003', contact_name: 'Lakshmi Menon', phone: '9800000003', email: 'hello@ecoseva.org', zones_served: ['Bangalore'], waste_types_accepted: ['Paper', 'Organic'], approved: true, total_pickups: 56, total_kg: 423 },
  { id: '4', org_name: 'CleanIndia NGO', reg_number: 'NGO-2024-004', contact_name: 'Rajesh Tiwari', phone: '9800000004', email: 'admin@cleanindia.ngo', zones_served: ['Delhi', 'Noida'], waste_types_accepted: ['Plastic', 'Paper', 'Metal', 'E-Waste'], approved: true, total_pickups: 201, total_kg: 1450 },
  { id: '5', org_name: 'HaritaDhara Trust', reg_number: 'NGO-2024-005', contact_name: 'Pooja Kulkarni', phone: '9800000005', email: 'reach@haritadhara.org', zones_served: ['Pune', 'Mumbai'], waste_types_accepted: ['Organic', 'Paper'], approved: false, total_pickups: 0, total_kg: 0 },
];

export const alerts = [
  { id: '1', bin_id: '7', bin_code: 'BIN-033', type: 'bin-full', severity: 'critical', message: 'BIN-033 at Indiranagar is critically full (97%)', resolved: false, timestamp: '2026-02-24T08:30:00Z' },
  { id: '2', bin_id: '2', bin_code: 'BIN-015', type: 'bin-full', severity: 'warning', message: 'BIN-015 at MG Road is nearing capacity (91%)', resolved: false, timestamp: '2026-02-24T07:45:00Z' },
  { id: '3', bin_id: '4', bin_code: 'BIN-067', type: 'bin-full', severity: 'warning', message: 'BIN-067 at Marine Drive fill level at 88%', resolved: false, timestamp: '2026-02-24T06:20:00Z' },
  { id: '4', bin_id: '1', bin_code: 'BIN-042', type: 'contamination', severity: 'warning', message: 'Contamination detected at BIN-042 Sector 15', resolved: false, timestamp: '2026-02-24T09:25:00Z' },
  { id: '5', bin_id: '3', bin_code: 'BIN-108', type: 'contamination', severity: 'warning', message: 'Contamination at BIN-108 Connaught Place', resolved: true, timestamp: '2026-02-24T09:10:00Z' },
  { id: '6', bin_id: '6', bin_code: 'BIN-091', type: 'sensor-offline', severity: 'info', message: 'BIN-091 sensor briefly offline, recovered', resolved: true, timestamp: '2026-02-23T22:00:00Z' },
];

export const transactions = [
  { id: '1', user_id: '1', type: 'earn', points: 20, description: 'Plastic recycled at BIN-042 • Sector 15', timestamp: '2026-02-24T09:42:00Z' },
  { id: '2', user_id: '1', type: 'earn', points: 20, description: 'Plastic recycled at BIN-023 • Koregaon Park', timestamp: '2026-02-24T09:20:00Z' },
  { id: '3', user_id: '1', type: 'redeem', points: -150, description: 'Redeemed: Jute Tote Bag', timestamp: '2026-02-23T15:00:00Z' },
  { id: '4', user_id: '1', type: 'earn', points: 10, description: 'Organic recycled at BIN-042 • Sector 15', timestamp: '2026-02-23T10:30:00Z' },
  { id: '5', user_id: '1', type: 'earn', points: 30, description: 'Metal recycled at BIN-108 • Connaught Place', timestamp: '2026-02-22T14:15:00Z' },
  { id: '6', user_id: '1', type: 'bonus', points: 50, description: '7-day streak bonus! 🔥', timestamp: '2026-02-22T00:00:00Z' },
  { id: '7', user_id: '1', type: 'earn', points: 15, description: 'Paper recycled at BIN-015 • MG Road', timestamp: '2026-02-21T11:00:00Z' },
  { id: '8', user_id: '1', type: 'ngo-donate', points: -100, description: 'Donated to GreenEarth Foundation 🤝', timestamp: '2026-02-20T16:00:00Z' },
];

export const recyclableBatches = [
  { id: '1', bin_id: '1', bin_code: 'BIN-042', location: 'Sector 15, Noida', category: 'plastic', estimated_weight_kg: 12.5, status: 'available', detected_at: '2026-02-24T08:00:00Z' },
  { id: '2', bin_id: '3', bin_code: 'BIN-108', location: 'Connaught Place, Delhi', category: 'paper', estimated_weight_kg: 8.3, status: 'available', detected_at: '2026-02-24T07:30:00Z' },
  { id: '3', bin_id: '2', bin_code: 'BIN-015', location: 'MG Road, Bangalore', category: 'metal', estimated_weight_kg: 5.7, status: 'claimed', detected_at: '2026-02-24T06:00:00Z', claimed_by: 'EcoSeva India' },
  { id: '4', bin_id: '5', bin_code: 'BIN-023', location: 'Koregaon Park, Pune', category: 'plastic', estimated_weight_kg: 15.2, status: 'available', detected_at: '2026-02-24T05:00:00Z' },
  { id: '5', bin_id: '4', bin_code: 'BIN-067', location: 'Marine Drive, Mumbai', category: 'e-waste', estimated_weight_kg: 3.1, status: 'collected', detected_at: '2026-02-23T12:00:00Z' },
];

export const achievements = [
  { id: '1', emoji: '🌟', title: 'First Recycle', description: 'Throw your first item', unlocked: true, date: '2026-01-15' },
  { id: '2', emoji: '🔥', title: '7-Day Streak', description: 'Active 7 days in a row', unlocked: true, date: '2026-02-22' },
  { id: '3', emoji: '⚡', title: 'E-Waste Hero', description: 'Recycle 5 e-waste items', unlocked: false, requirement: 'Recycle 5 e-waste items' },
  { id: '4', emoji: '💯', title: 'Century', description: 'Recycle 100 items total', unlocked: true, date: '2026-02-10' },
  { id: '5', emoji: '🏆', title: 'Top Recycler', description: 'Reach #1 in your ward', unlocked: false, requirement: 'Reach #1 in your ward' },
  { id: '6', emoji: '🛍️', title: 'First Redemption', description: 'Redeem your first product', unlocked: true, date: '2026-02-23' },
  { id: '7', emoji: '🤝', title: 'Eco Supporter', description: 'Donate points to an NGO', unlocked: true, date: '2026-02-20' },
  { id: '8', emoji: '🌳', title: 'Green Legend', description: 'Earn 10,000 lifetime points', unlocked: false, requirement: 'Earn 10,000 lifetime points' },
];

export const levels = [
  { level: 1, title: '🌱 Eco Newcomer', min: 0, max: 199 },
  { level: 2, title: '🌿 Green Starter', min: 200, max: 499 },
  { level: 3, title: '⚡ Eco Warrior', min: 500, max: 999 },
  { level: 4, title: '🔋 Recycle Pro', min: 1000, max: 1999 },
  { level: 5, title: '🌳 Sustainability Champ', min: 2000, max: 3999 },
  { level: 6, title: '🛡️ Green Guardian', min: 4000, max: 7999 },
  { level: 7, title: '🏆 Eco Legend', min: 8000, max: 14999 },
  { level: 8, title: '👑 Swachh Hero', min: 15000, max: Infinity },
];

export const hourlyData = [
  { hour: '1:00', disposals: 12, avg: 15 }, { hour: '3:00', disposals: 8, avg: 12 },
  { hour: '5:00', disposals: 5, avg: 8 }, { hour: '7:00', disposals: 35, avg: 30 },
  { hour: '9:00', disposals: 65, avg: 55 }, { hour: '11:00', disposals: 78, avg: 60 },
  { hour: '13:00', disposals: 85, avg: 70 }, { hour: '15:00', disposals: 72, avg: 65 },
  { hour: '17:00', disposals: 90, avg: 75 }, { hour: '19:00', disposals: 55, avg: 50 },
  { hour: '21:00', disposals: 30, avg: 35 }, { hour: '23:00', disposals: 15, avg: 20 },
];

export const wasteDistribution = [
  { name: 'Plastic', value: 35, color: '#2B7FD4' },
  { name: 'Paper', value: 25, color: '#2D9E68' },
  { name: 'Metal', value: 15, color: '#F4873B' },
  { name: 'Organic', value: 20, color: '#6FCF97' },
  { name: 'E-Waste', value: 5, color: '#D94F3D' },
];

export function timeAgo(dateStr: string): string {
  const now = new Date();
  const date = new Date(dateStr);
  const diffMs = now.getTime() - date.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  if (diffMin < 1) return 'Just now';
  if (diffMin < 60) return `${diffMin} min ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;
  return `${Math.floor(diffHr / 24)}d ago`;
}

export function getLevelInfo(points: number) {
  return levels.find(l => points >= l.min && points <= l.max) || levels[0];
}

export function getNextLevelXP(points: number) {
  const current = getLevelInfo(points);
  const next = levels.find(l => l.level === current.level + 1);
  return next ? next.min : current.max;
}
