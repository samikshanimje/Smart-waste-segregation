import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Recycle, Eye, EyeOff, Phone, Mail, Lock, User, Building2, MapPin } from 'lucide-react';
import { toast } from 'sonner';

type Role = 'citizen' | 'admin' | 'ngo';

export default function Login() {
  const [role, setRole] = useState<Role>('citizen');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = (path: string) => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      toast.success('Login successful!');
      navigate(path);
    }, 800);
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="w-full max-w-md">
        <div className="bg-card border border-border rounded-2xl shadow-md p-8">
          <div className="text-center mb-6">
            <Link to="/" className="inline-flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-xl bg-green-500 flex items-center justify-center">
                <Recycle className="w-6 h-6 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold text-green-700">SwachhSmart</span>
            </Link>
            <h1 className="text-xl font-bold text-foreground">Welcome back</h1>
          </div>

          <div className="bg-background rounded-xl p-1 flex mb-6">
            {(['citizen', 'admin', 'ngo'] as Role[]).map(r => (
              <button key={r} onClick={() => setRole(r)}
                className={`flex-1 py-2 text-sm font-semibold rounded-lg transition-all capitalize ${role === r ? 'bg-card shadow-sm text-green-700' : 'text-muted-foreground'}`}>
                {r === 'ngo' ? 'NGO' : r.charAt(0).toUpperCase() + r.slice(1)}
              </button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            {role === 'citizen' && <CitizenForm key="citizen" loading={loading} onLogin={() => handleLogin('/citizen/dashboard')} />}
            {role === 'admin' && <AdminForm key="admin" loading={loading} onLogin={() => handleLogin('/admin/dashboard')} />}
            {role === 'ngo' && <NgoForm key="ngo" loading={loading} onLogin={() => handleLogin('/ngo/dashboard')} />}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
}

function CitizenForm({ loading, onLogin }: { loading: boolean; onLogin: () => void }) {
  const [step, setStep] = useState<'phone' | 'otp' | 'register'>('phone');
  const [phone, setPhone] = useState('');

  return (
    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
      <p className="text-sm font-semibold text-foreground mb-1">Citizen Login</p>
      <p className="text-xs text-muted-foreground mb-4">Enter your registered mobile number</p>

      {step === 'phone' && (
        <>
          <div className="flex gap-2 mb-4">
            <div className="flex items-center bg-background border border-border rounded-xl px-3 text-sm font-medium text-muted-foreground">+91</div>
            <div className="relative flex-1">
              <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input type="tel" placeholder="Mobile Number" value={phone} onChange={e => setPhone(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary" />
            </div>
          </div>
          <button onClick={() => setStep('otp')} className="w-full bg-green-500 text-primary-foreground rounded-xl py-2.5 font-semibold hover:bg-green-700 transition-colors">Send OTP</button>
        </>
      )}

      {step === 'otp' && (
        <>
          <div className="flex gap-3 justify-center mb-4">
            {[1, 2, 3, 4].map(i => (
              <input key={i} type="text" maxLength={1} defaultValue={i.toString()}
                className="w-12 h-12 text-center text-lg font-bold bg-background border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary" />
            ))}
          </div>
          <button onClick={onLogin} disabled={loading}
            className="w-full bg-green-500 text-primary-foreground rounded-xl py-2.5 font-semibold hover:bg-green-700 transition-colors disabled:opacity-50">
            {loading ? 'Verifying...' : 'Verify & Continue'}
          </button>
        </>
      )}

      {step === 'register' && (
        <>
          <InputField icon={User} placeholder="Full Name" />
          <InputField icon={Phone} placeholder="Mobile Number" />
          <InputField icon={MapPin} placeholder="Ward / Zone" />
          <button onClick={onLogin} disabled={loading}
            className="w-full bg-green-500 text-primary-foreground rounded-xl py-2.5 font-semibold hover:bg-green-700 transition-colors disabled:opacity-50">
            {loading ? 'Registering...' : 'Register'}
          </button>
        </>
      )}

      <p className="text-center text-xs text-muted-foreground mt-4">
        {step === 'register' ? (
          <button onClick={() => setStep('phone')} className="text-green-700 font-semibold">← Back to Login</button>
        ) : (
          <>New user? <button onClick={() => setStep('register')} className="text-green-700 font-semibold">Register →</button></>
        )}
      </p>
    </motion.div>
  );
}

function AdminForm({ loading, onLogin }: { loading: boolean; onLogin: () => void }) {
  const [showPw, setShowPw] = useState(false);
  return (
    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
      <p className="text-sm font-semibold text-foreground mb-1">Admin Login</p>
      <p className="text-xs text-muted-foreground mb-4">Sign in with your admin credentials</p>
      <InputField icon={Mail} placeholder="Email" defaultValue="admin@swachhsmart.in" />
      <div className="relative mb-4">
        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input type={showPw ? 'text' : 'password'} placeholder="Password" defaultValue="admin123"
          className="w-full pl-10 pr-10 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary" />
        <button onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
          {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
        </button>
      </div>
      <button onClick={onLogin} disabled={loading}
        className="w-full bg-green-500 text-primary-foreground rounded-xl py-2.5 font-semibold hover:bg-green-700 transition-colors disabled:opacity-50">
        {loading ? 'Signing in...' : 'Sign In to Dashboard'}
      </button>
      <p className="text-center text-[10px] text-muted-foreground mt-3 bg-background rounded-lg p-2">Hint: admin@swachhsmart.in / admin123</p>
    </motion.div>
  );
}

function NgoForm({ loading, onLogin }: { loading: boolean; onLogin: () => void }) {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  return (
    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
      <div className="flex gap-2 mb-4">
        <button onClick={() => setMode('login')} className={`flex-1 py-1.5 text-sm font-semibold rounded-lg ${mode === 'login' ? 'bg-green-100 text-green-700' : 'text-muted-foreground'}`}>Login</button>
        <button onClick={() => setMode('register')} className={`flex-1 py-1.5 text-sm font-semibold rounded-lg ${mode === 'register' ? 'bg-green-100 text-green-700' : 'text-muted-foreground'}`}>Register</button>
      </div>
      {mode === 'login' ? (
        <>
          <InputField icon={Mail} placeholder="Email" />
          <InputField icon={Lock} placeholder="Password" type="password" />
          <button onClick={onLogin} disabled={loading}
            className="w-full bg-green-500 text-primary-foreground rounded-xl py-2.5 font-semibold hover:bg-green-700 transition-colors disabled:opacity-50">
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </>
      ) : (
        <>
          <InputField icon={Building2} placeholder="Organization Name" />
          <InputField icon={User} placeholder="Registration Number" />
          <InputField icon={User} placeholder="Contact Person Name" />
          <InputField icon={Phone} placeholder="Phone" />
          <InputField icon={Mail} placeholder="Email" />
          <InputField icon={Lock} placeholder="Password" type="password" />
          <button onClick={() => { toast.success('Registration submitted! Pending admin approval.'); }}
            className="w-full bg-saffron-500 text-primary-foreground rounded-xl py-2.5 font-semibold hover:opacity-90 transition-opacity">
            Submit Registration
          </button>
        </>
      )}
    </motion.div>
  );
}

function InputField({ icon: Icon, placeholder, type = 'text', defaultValue }: { icon: React.ComponentType<{ className?: string }>; placeholder: string; type?: string; defaultValue?: string }) {
  return (
    <div className="relative mb-3">
      <Icon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
      <input type={type} placeholder={placeholder} defaultValue={defaultValue}
        className="w-full pl-10 pr-4 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary" />
    </div>
  );
}
