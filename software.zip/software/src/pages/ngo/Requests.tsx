export default function NgoRequests() {
  const requests = [
    { id: '1', batch: 'BIN-042 — Plastic — 12.5kg', status: 'pending', date: 'Feb 24, 10:30 AM' },
    { id: '2', batch: 'BIN-108 — Paper — 8.3kg', status: 'approved', date: 'Feb 23, 2:15 PM' },
    { id: '3', batch: 'BIN-067 — E-Waste — 3.1kg', status: 'collected', date: 'Feb 22, 9:00 AM' },
    { id: '4', batch: 'BIN-023 — Plastic — 15.2kg', status: 'rejected', date: 'Feb 21, 4:00 PM', note: 'Area already assigned to another NGO' },
  ];

  const statusStyles: Record<string, string> = {
    pending: 'bg-saffron-100 text-saffron-500',
    approved: 'bg-green-100 text-green-700',
    collected: 'bg-blue-100 text-blue-500',
    rejected: 'bg-destructive/10 text-destructive',
  };

  return (
    <div>
      <h1 className="text-2xl font-bold text-foreground mb-6">My Pickup Requests</h1>
      <div className="space-y-4">
        {requests.map(r => (
          <div key={r.id} className="bg-card border border-border rounded-2xl p-5 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm font-semibold text-foreground">{r.batch}</p>
              <span className={`text-xs rounded-full px-3 py-1 font-semibold capitalize ${statusStyles[r.status]}`}>{r.status}</span>
            </div>
            <p className="text-xs text-muted-foreground">Requested: {r.date}</p>
            {r.status === 'approved' && (
              <button className="mt-3 bg-green-500 text-primary-foreground rounded-xl px-4 py-2 text-sm font-semibold hover:bg-green-700 transition-colors">Mark as Collected</button>
            )}
            {r.status === 'rejected' && r.note && (
              <div className="mt-2 bg-destructive/5 border border-destructive/20 rounded-lg p-3 text-xs text-destructive">{r.note}</div>
            )}
            {r.status === 'pending' && <p className="text-xs text-muted-foreground italic mt-2">Awaiting admin approval...</p>}
          </div>
        ))}
      </div>
    </div>
  );
}
