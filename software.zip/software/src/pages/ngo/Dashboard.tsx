import { Package, CheckCircle, Clock, MapPin } from 'lucide-react';
import { recyclableBatches } from '@/lib/mock-data';
import { toast } from 'sonner';

export default function NgoDashboard() {
  const stats = [
    { label: 'Pickups Completed', value: '124' },
    { label: 'Total kg Collected', value: '892' },
    { label: 'Pending Requests', value: '3' },
    { label: 'Zones Active', value: '2' },
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold text-foreground mb-1">Available Pickups</h1>
      <p className="text-sm text-muted-foreground mb-6">Browse and claim recyclable waste batches</p>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {stats.map((s, i) => (
          <div key={i} className="bg-card border border-border rounded-2xl p-4 shadow-sm">
            <p className="text-2xl font-bold text-foreground">{s.value}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="space-y-4">
        {recyclableBatches.filter(b => b.status !== 'collected').map(b => (
          <div key={b.id} className={`bg-card border border-border rounded-2xl p-5 transition-all ${b.status === 'claimed' ? 'opacity-60' : 'hover:shadow-md hover:-translate-y-0.5'}`}>
            <div className="flex items-center justify-between mb-2">
              <span className="bg-blue-100 text-blue-500 text-xs rounded-full px-3 py-1 font-semibold capitalize">{b.category}</span>
              <span className="bg-green-100 text-green-700 text-xs rounded-full px-2 py-0.5 font-semibold flex items-center gap-1"><Clock className="w-3 h-3" />Available</span>
            </div>
            <div className="flex items-center gap-2 mb-1">
              <MapPin className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm font-semibold text-foreground">{b.bin_code} — {b.location}</span>
            </div>
            <p className="text-sm font-bold text-foreground mb-1">~{b.estimated_weight_kg} kg estimated</p>
            {b.status === 'available' ? (
              <button onClick={() => toast.success('Pickup requested! Awaiting admin approval.')}
                className="w-full mt-3 bg-saffron-500 text-primary-foreground rounded-xl py-2.5 font-semibold hover:opacity-90 transition-opacity">
                Request Pickup
              </button>
            ) : (
              <p className="text-xs text-saffron-500 mt-2 font-semibold">Claimed by {b.claimed_by}</p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
