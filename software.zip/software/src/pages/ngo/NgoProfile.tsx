export default function NgoProfile() {
  return (
    <div>
      <div className="bg-card border border-border rounded-2xl p-6 shadow-sm mb-6 text-center">
        <div className="w-16 h-16 rounded-xl bg-green-100 flex items-center justify-center text-green-700 font-bold text-xl mx-auto mb-3">GE</div>
        <h2 className="text-xl font-bold text-foreground">GreenEarth Foundation</h2>
        <p className="text-xs text-muted-foreground mb-2">Reg: NGO-2024-001</p>
        <span className="bg-green-100 text-green-700 text-xs rounded-full px-3 py-1 font-semibold">✓ Approved</span>
      </div>

      <div className="bg-green-100 border-l-4 border-green-500 rounded-xl p-5 mb-6">
        <h3 className="font-bold text-foreground mb-3">Impact Summary</h3>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div><span className="text-muted-foreground">Total Waste Diverted</span><p className="font-bold text-foreground">892 kg</p></div>
          <div><span className="text-muted-foreground">Bins Served</span><p className="font-bold text-foreground">18 unique</p></div>
          <div><span className="text-muted-foreground">Cities Active</span><p className="font-bold text-foreground">2</p></div>
          <div><span className="text-muted-foreground">Member Since</span><p className="font-bold text-foreground">Oct 2025</p></div>
        </div>
      </div>

      <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
        <h3 className="font-bold text-foreground mb-4">Organization Details</h3>
        <div className="space-y-3 text-sm">
          {[['Contact Person', 'Meera Iyer'], ['Phone', '9800000001'], ['Email', 'contact@greenearth.org'], ['Zones', 'Noida, Delhi'], ['Waste Types', 'Plastic, Paper, Metal']].map(([l, v]) => (
            <div key={l} className="flex justify-between py-2 border-b border-background last:border-0">
              <span className="text-muted-foreground">{l}</span>
              <span className="font-medium text-foreground">{v}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
