import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const monthlyPickups = [
  { month: 'Sep', pickups: 12 }, { month: 'Oct', pickups: 18 }, { month: 'Nov', pickups: 22 },
  { month: 'Dec', pickups: 25 }, { month: 'Jan', pickups: 28 }, { month: 'Feb', pickups: 19 },
];

export default function NgoHistory() {
  return (
    <div>
      <h1 className="text-2xl font-bold text-foreground mb-6">Collection History</h1>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {[{ l: 'Total Pickups', v: '124' }, { l: 'Total kg', v: '892' }, { l: 'This Month', v: '19' }, { l: 'Avg per Pickup', v: '7.2kg' }].map((s, i) => (
          <div key={i} className="bg-card border border-border rounded-2xl p-4 shadow-sm">
            <p className="text-2xl font-bold text-foreground">{s.v}</p>
            <p className="text-xs text-muted-foreground">{s.l}</p>
          </div>
        ))}
      </div>

      <div className="bg-card border border-border rounded-2xl p-5 shadow-sm mb-6">
        <h3 className="text-sm font-bold text-foreground mb-4">Monthly Pickups</h3>
        <ResponsiveContainer width="100%" height={250}>
          <BarChart data={monthlyPickups}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E2EBE6" vertical={false} />
            <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#7A9A87' }} />
            <YAxis tick={{ fontSize: 11, fill: '#7A9A87' }} />
            <Tooltip contentStyle={{ borderRadius: 12, fontSize: 12 }} />
            <Bar dataKey="pickups" fill="#2D9E68" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
