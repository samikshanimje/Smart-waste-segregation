const notifications = [
  { id: '1', icon: '🟢', text: 'New plastic batch available at BIN-042 Sector 15 — 12kg', time: '10 min ago', read: false },
  { id: '2', icon: '✅', text: 'Your pickup request for BIN-015 has been approved!', time: '2 hours ago', read: false },
  { id: '3', icon: '❌', text: 'Pickup request rejected — Area already assigned', time: '1 day ago', read: true },
  { id: '4', icon: '⏰', text: 'Reminder: Pickup at BIN-042 in 1 hour', time: '1 day ago', read: true },
  { id: '5', icon: '🟢', text: 'New paper batch available at BIN-108 Connaught Place — 8.3kg', time: '2 days ago', read: true },
];

export default function NgoNotifications() {
  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-foreground">Notifications</h1>
        <button className="text-xs text-info font-semibold">Mark All Read</button>
      </div>
      <div className="space-y-2">
        {notifications.map(n => (
          <div key={n.id} className={`rounded-xl p-4 flex items-start gap-3 transition-colors ${n.read ? 'bg-card border border-border opacity-70' : 'bg-background border-l-4 border-l-green-500 border border-border'}`}>
            <span className="text-lg">{n.icon}</span>
            <div className="flex-1">
              <p className="text-sm text-foreground">{n.text}</p>
              <p className="text-xs text-muted-foreground mt-1">{n.time}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
