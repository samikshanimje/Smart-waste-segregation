import { useState, useEffect, useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import CountUp from 'react-countup';
import { Link } from 'react-router-dom';
import {
  Recycle, Leaf, Smartphone, Coins, ChevronRight, Menu, X,
  Bot, Gamepad2, BarChart3, Trash2, CheckCircle2, ArrowRight,
  Users, Building2, Package, TrendingUp
} from 'lucide-react';

const fadeUp = {
  hidden: { opacity: 0, y: 32 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.55, ease: [0.25, 0.46, 0.45, 0.94] as const } }
};
const stagger = { hidden: {}, visible: { transition: { staggerChildren: 0.12 } } };

function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', h);
    return () => window.removeEventListener('scroll', h);
  }, []);

  const links = [
    { label: 'Problem', href: '#problem' },
    { label: 'Solution', href: '#solution' },
    { label: 'How It Works', href: '#how-it-works' },
    { label: 'Impact', href: '#impact' },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-card/90 backdrop-blur-md shadow-sm border-b border-border' : 'bg-transparent'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-green-500 flex items-center justify-center">
            <Recycle className="w-5 h-5 text-primary-foreground" />
          </div>
          <span className="text-lg font-bold text-green-700">SwachhSmart</span>
        </Link>
        <div className="hidden md:flex items-center gap-8">
          {links.map(l => (
            <a key={l.href} href={l.href} className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">{l.label}</a>
          ))}
        </div>
        <div className="hidden md:flex items-center gap-3">
          <Link to="/login" className="text-sm font-semibold text-green-700 hover:text-green-900 transition-colors">Login</Link>
          <Link to="/login" className="bg-saffron-500 text-primary-foreground rounded-xl px-5 py-2.5 text-sm font-semibold hover:opacity-90 transition-opacity">Get Started</Link>
        </div>
        <button onClick={() => setOpen(!open)} className="md:hidden p-2">
          {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>
      {open && (
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="md:hidden bg-card border-b border-border px-4 pb-4">
          {links.map(l => (
            <a key={l.href} href={l.href} onClick={() => setOpen(false)} className="block py-3 text-sm font-medium text-muted-foreground">{l.label}</a>
          ))}
          <Link to="/login" className="block w-full text-center bg-saffron-500 text-primary-foreground rounded-xl px-5 py-2.5 text-sm font-semibold mt-2">Get Started</Link>
        </motion.div>
      )}
    </nav>
  );
}

function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden bg-gradient-to-br from-green-700 via-green-500 to-green-300">
      <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg width=\'60\' height=\'60\' viewBox=\'0 0 60 60\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cg fill=\'none\' fill-rule=\'evenodd\'%3E%3Cg fill=\'%23ffffff\' fill-opacity=\'1\'%3E%3Cpath d=\'M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z\'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")' }} />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-32 w-full grid lg:grid-cols-2 gap-12 items-center relative z-10">
        <motion.div initial="hidden" animate="visible" variants={stagger}>
          <motion.div variants={fadeUp} className="inline-flex items-center gap-2 bg-primary-foreground/10 border border-primary-foreground/20 rounded-full px-4 py-1.5 mb-6">
            <span className="text-sm">🇮🇳</span>
            <span className="text-primary-foreground/90 text-sm font-medium">Swachh Bharat Mission</span>
          </motion.div>
          <motion.h1 variants={fadeUp} className="text-4xl sm:text-5xl lg:text-[56px] font-extrabold text-primary-foreground leading-tight mb-6">
            AI-Powered Smart Waste Segregation
          </motion.h1>
          <motion.p variants={fadeUp} className="text-lg text-primary-foreground/80 mb-8 max-w-lg leading-relaxed">
            Earn rewards for responsible disposal. Our AI-powered smart bins classify waste instantly and reward you with points. Together, let's build a cleaner India.
          </motion.p>
          <motion.div variants={fadeUp} className="flex flex-wrap gap-4">
            <Link to="/login" className="bg-saffron-500 text-primary-foreground rounded-xl px-6 py-3 font-semibold hover:opacity-90 transition-opacity flex items-center gap-2">
              Start Earning Points <ArrowRight className="w-4 h-4" />
            </Link>
            <a href="#how-it-works" className="border border-primary-foreground/40 text-primary-foreground rounded-xl px-6 py-3 font-semibold hover:bg-primary-foreground/10 transition-colors">
              See How It Works
            </a>
          </motion.div>
        </motion.div>
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.7, delay: 0.3 }} className="relative hidden lg:block">
          <div className="relative w-full h-[420px] flex items-center justify-center">
            <div className="w-64 h-80 bg-primary-foreground/10 rounded-3xl border border-primary-foreground/20 backdrop-blur-sm flex items-center justify-center">
              <Recycle className="w-32 h-32 text-primary-foreground/40" />
            </div>
            <motion.div animate={{ y: [0, -8, 0] }} transition={{ duration: 3, repeat: Infinity }} className="absolute top-8 right-8 bg-card rounded-xl shadow-xl px-4 py-3 flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-green-100 flex items-center justify-center"><CheckCircle2 className="w-4 h-4 text-green-700" /></div>
              <div><p className="text-xs font-bold text-foreground">95% Accuracy</p><p className="text-[10px] text-muted-foreground">AI Classification</p></div>
            </motion.div>
            <motion.div animate={{ y: [0, 8, 0] }} transition={{ duration: 3.5, repeat: Infinity }} className="absolute bottom-16 left-0 bg-card rounded-xl shadow-xl px-4 py-3 flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-saffron-100 flex items-center justify-center"><Coins className="w-4 h-4 text-saffron-500" /></div>
              <div><p className="text-xs font-bold text-foreground">+50 Coins Earned!</p><p className="text-[10px] text-muted-foreground">Just now</p></div>
            </motion.div>
            <motion.div animate={{ y: [0, -6, 0] }} transition={{ duration: 4, repeat: Infinity }} className="absolute bottom-8 right-4 bg-card rounded-xl shadow-xl px-4 py-3">
              <p className="text-[10px] text-muted-foreground mb-1">Bin 78% Full</p>
              <div className="w-24 h-2 bg-border rounded-full overflow-hidden"><div className="h-full bg-green-500 rounded-full" style={{ width: '78%' }} /></div>
            </motion.div>
          </div>
        </motion.div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-background to-transparent" />
    </section>
  );
}

function AnimatedSection({ children, className = '', id }: { children: React.ReactNode; className?: string; id?: string }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-80px' });
  return (
    <motion.section ref={ref} id={id} initial="hidden" animate={isInView ? 'visible' : 'hidden'} variants={stagger} className={className}>
      {children}
    </motion.section>
  );
}

function ChallengeSection() {
  const cards = [
    { icon: Trash2, title: '62M Tonnes/Year', desc: 'India generates over 62 million tonnes of waste annually, growing at 5% each year.' },
    { icon: TrendingUp, title: '80% Untreated', desc: 'Only 20% of collected waste is actually processed and recycled properly.' },
    { icon: Users, title: 'Public Health Risk', desc: 'Improper waste management leads to contaminated water, soil, and air pollution.' },
  ];
  return (
    <AnimatedSection className="py-20 bg-card" id="problem">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <motion.div variants={fadeUp} className="text-center mb-12">
          <span className="text-saffron-500 text-xs font-semibold tracking-widest uppercase">THE CHALLENGE</span>
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mt-3 mb-4">India's Waste Crisis</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">62 million tonnes of waste generated annually, yet only 20% is processed. Contamination at source makes recycling nearly impossible.</p>
        </motion.div>
        <div className="grid md:grid-cols-3 gap-6">
          {cards.map((c, i) => (
            <motion.div key={i} variants={fadeUp} className="bg-card border border-border rounded-2xl p-6 hover:shadow-md hover:-translate-y-1 transition-all duration-200">
              <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center mb-4">
                <c.icon className="w-6 h-6 text-green-700" />
              </div>
              <h3 className="text-xl font-bold text-foreground mb-2">{c.title}</h3>
              <p className="text-sm text-muted-foreground">{c.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </AnimatedSection>
  );
}

function SolutionSection() {
  const cards = [
    { icon: Bot, title: 'AI Classification', desc: 'Advanced ML models classify waste in real-time with 95% accuracy, guiding users to dispose correctly.', color: 'bg-green-100 text-green-700' },
    { icon: Gamepad2, title: 'Gamified Rewards', desc: 'Earn SwachhCoins, unlock badges, climb leaderboards, and redeem eco-products in the SwachhMart.', color: 'bg-saffron-100 text-saffron-500' },
    { icon: BarChart3, title: 'City Analytics', desc: 'Real-time dashboards for city admins to monitor bins, optimize routes, and track recycling rates.', color: 'bg-blue-100 text-blue-500' },
  ];
  return (
    <AnimatedSection className="py-20 bg-background" id="solution">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <motion.div variants={fadeUp} className="text-center mb-12">
          <span className="text-green-500 text-xs font-semibold tracking-widest uppercase">OUR SOLUTION</span>
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mt-3 mb-4">AI + IoT + Gamification</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">Smart bins powered by artificial intelligence that classify, reward, and report — making waste management engaging and data-driven.</p>
        </motion.div>
        <div className="grid md:grid-cols-3 gap-6">
          {cards.map((c, i) => (
            <motion.div key={i} variants={fadeUp} className="bg-card border border-border rounded-2xl p-6 hover:shadow-md hover:-translate-y-1 transition-all duration-200">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${c.color}`}>
                <c.icon className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-foreground mb-2">{c.title}</h3>
              <p className="text-sm text-muted-foreground">{c.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </AnimatedSection>
  );
}

function HowItWorksSection() {
  const steps = [
    { num: '01', icon: Trash2, title: 'Dispose', desc: 'Drop your waste into the smart bin. AI instantly classifies it.' },
    { num: '02', icon: Smartphone, title: 'Tap NFC', desc: 'Tap your phone on the bin to claim your reward points.' },
    { num: '03', icon: Coins, title: 'Earn', desc: 'Points are credited instantly. Redeem for eco-products and more.' },
  ];
  return (
    <AnimatedSection className="py-20 bg-card" id="how-it-works">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <motion.div variants={fadeUp} className="text-center mb-16">
          <span className="text-saffron-500 text-xs font-semibold tracking-widest uppercase">SIMPLE PROCESS</span>
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mt-3">How It Works</h2>
        </motion.div>
        <div className="grid md:grid-cols-3 gap-8 relative">
          <div className="hidden md:block absolute top-16 left-[20%] right-[20%] border-t-2 border-dashed border-border" />
          {steps.map((s, i) => (
            <motion.div key={i} variants={fadeUp} className="text-center relative z-10">
              <span className="text-7xl font-extrabold text-border/50 absolute -top-4 left-1/2 -translate-x-1/2">{s.num}</span>
              <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4 mt-8 relative">
                <s.icon className="w-7 h-7 text-green-700" />
              </div>
              <h3 className="text-lg font-bold text-foreground mb-2">{s.title}</h3>
              <p className="text-sm text-muted-foreground max-w-xs mx-auto">{s.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </AnimatedSection>
  );
}

function ImpactSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });
  const stats = [
    { num: 50000, suffix: '+', label: 'Waste Events' },
    { num: 12000, suffix: '+', label: 'Active Citizens' },
    { num: 340, suffix: '', label: 'Bins Deployed' },
    { num: 85, suffix: '%', label: 'Recycling Rate' },
  ];
  return (
    <section ref={ref} className="py-20 bg-gradient-to-br from-green-700 to-green-900" id="impact">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 text-center">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={isInView ? { opacity: 1, y: 0 } : {}} transition={{ duration: 0.5 }}>
          <h2 className="text-3xl sm:text-4xl font-bold text-primary-foreground mb-3">Our Impact</h2>
          <p className="text-green-300 mb-12">Measurable change, one disposal at a time.</p>
        </motion.div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((s, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={isInView ? { opacity: 1, y: 0 } : {}} transition={{ delay: i * 0.15, duration: 0.5 }} className={`${i < 3 ? 'md:border-r md:border-primary-foreground/20' : ''}`}>
              <div className="text-4xl sm:text-5xl font-bold text-primary-foreground">
                {isInView && <CountUp end={s.num} duration={2.5} separator="," />}{s.suffix}
              </div>
              <p className="text-green-300 text-sm mt-2">{s.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ForCitizensAndCities() {
  return (
    <AnimatedSection className="py-20 bg-card">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 grid md:grid-cols-2 gap-6">
        <motion.div variants={fadeUp} className="bg-card border border-border rounded-2xl p-6 border-l-4 border-l-saffron-500 hover:shadow-md transition-shadow">
          <div className="flex items-center gap-3 mb-5">
            <div className="w-10 h-10 rounded-xl bg-saffron-100 flex items-center justify-center"><Users className="w-5 h-5 text-saffron-500" /></div>
            <h3 className="text-xl font-bold text-foreground">For Citizens</h3>
          </div>
          {['Earn points every time you dispose waste correctly', 'Unlock badges and climb the leaderboard', 'Simple NFC tap-to-earn from your phone'].map((t, i) => (
            <div key={i} className="flex items-start gap-3 mb-3"><CheckCircle2 className="w-5 h-5 text-saffron-500 mt-0.5 flex-shrink-0" /><p className="text-sm text-muted-foreground">{t}</p></div>
          ))}
          <Link to="/login" className="mt-4 block w-full text-center bg-saffron-500 text-primary-foreground rounded-xl px-5 py-2.5 font-semibold hover:opacity-90 transition-opacity">Join as Citizen →</Link>
        </motion.div>
        <motion.div variants={fadeUp} className="bg-card border border-border rounded-2xl p-6 border-l-4 border-l-green-500 hover:shadow-md transition-shadow">
          <div className="flex items-center gap-3 mb-5">
            <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center"><Building2 className="w-5 h-5 text-green-700" /></div>
            <h3 className="text-xl font-bold text-foreground">For Cities</h3>
          </div>
          {['Real-time waste analytics and dashboards', 'AI-powered contamination detection', 'Optimize collection routes and schedules'].map((t, i) => (
            <div key={i} className="flex items-start gap-3 mb-3"><CheckCircle2 className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" /><p className="text-sm text-muted-foreground">{t}</p></div>
          ))}
          <Link to="/admin/dashboard" className="mt-4 block w-full text-center bg-green-500 text-primary-foreground rounded-xl px-5 py-2.5 font-semibold hover:opacity-90 transition-opacity">Admin Dashboard →</Link>
        </motion.div>
      </div>
    </AnimatedSection>
  );
}

function NgoConnectSection() {
  const nodes = [
    { icon: Package, label: 'Waste Detected' },
    { icon: Users, label: 'NGOs Notified' },
    { icon: Trash2, label: 'Pickup Requested' },
    { icon: Recycle, label: 'Waste Diverted' },
  ];
  const ngoNames = ['GreenEarth Foundation', 'RecycleBharat', 'EcoSeva India', 'CleanIndia NGO', 'HaritaDhara Trust'];
  return (
    <AnimatedSection className="py-20 bg-background">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 text-center">
        <motion.div variants={fadeUp}>
          <span className="text-green-500 text-xs font-semibold tracking-widest uppercase">NGO CONNECT</span>
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mt-3 mb-12">Closing the Recycling Loop</h2>
        </motion.div>
        <motion.div variants={fadeUp} className="flex flex-wrap justify-center items-center gap-2 sm:gap-4 mb-10">
          {nodes.map((n, i) => (
            <div key={i} className="flex items-center gap-2 sm:gap-4">
              <div className="bg-card border border-border rounded-xl p-4 shadow-sm flex flex-col items-center gap-2 min-w-[100px]">
                <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center"><n.icon className="w-5 h-5 text-green-700" /></div>
                <span className="text-xs font-semibold text-foreground">{n.label}</span>
              </div>
              {i < 3 && <ChevronRight className="w-5 h-5 text-muted-foreground hidden sm:block" />}
            </div>
          ))}
        </motion.div>
        <motion.div variants={fadeUp} className="flex flex-wrap justify-center gap-2 mb-8">
          {ngoNames.map(n => (
            <span key={n} className="bg-green-100 text-green-700 rounded-full px-4 py-1.5 text-xs font-semibold">{n}</span>
          ))}
        </motion.div>
        <motion.div variants={fadeUp}>
          <Link to="/login" className="inline-flex border border-green-500 text-green-700 rounded-xl px-6 py-2.5 font-semibold hover:bg-green-100 transition-colors">Register Your NGO →</Link>
        </motion.div>
      </div>
    </AnimatedSection>
  );
}

function CTASection() {
  return (
    <AnimatedSection className="py-20 bg-card text-center">
      <div className="max-w-2xl mx-auto px-4">
        <motion.h2 variants={fadeUp} className="text-3xl sm:text-4xl font-bold text-foreground mb-4">Ready to Make a Difference?</motion.h2>
        <motion.p variants={fadeUp} className="text-muted-foreground mb-8">Join thousands of citizens building a cleaner, greener India.</motion.p>
        <motion.div variants={fadeUp}>
          <Link to="/login" className="inline-flex bg-saffron-500 text-primary-foreground rounded-xl px-8 py-3.5 text-lg font-semibold hover:opacity-90 transition-opacity">Get Started Free</Link>
        </motion.div>
      </div>
    </AnimatedSection>
  );
}

function Footer() {
  return (
    <footer className="bg-green-900 text-primary-foreground py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-green-500 flex items-center justify-center"><Recycle className="w-5 h-5 text-primary-foreground" /></div>
          <div>
            <span className="font-bold">SwachhSmart</span>
            <p className="text-xs text-green-300">Powered by AI. Driven by Citizens. Built for Bharat.</p>
          </div>
        </div>
        <div className="flex gap-6 text-sm text-green-300">
          <a href="#problem" className="hover:text-primary-foreground transition-colors">About</a>
          <a href="#solution" className="hover:text-primary-foreground transition-colors">Features</a>
          <a href="#impact" className="hover:text-primary-foreground transition-colors">Impact</a>
          <Link to="/login" className="hover:text-primary-foreground transition-colors">Login</Link>
        </div>
        <p className="text-xs text-green-300">© 2026 SwachhSmart. Swachh Bharat Mission.</p>
      </div>
    </footer>
  );
}

export default function Landing() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <HeroSection />
      <ChallengeSection />
      <SolutionSection />
      <HowItWorksSection />
      <ImpactSection />
      <ForCitizensAndCities />
      <NgoConnectSection />
      <CTASection />
      <Footer />
    </div>
  );
}
