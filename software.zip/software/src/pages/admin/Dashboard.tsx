import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { Recycle, Trash2, AlertTriangle, Activity, TrendingUp, TrendingDown } from 'lucide-react';
import { classifications, bins, hourlyData, wasteDistribution, timeAgo } from '@/lib/mock-data';

const kpis = [
  { label: 'Total Processed', value: '12,458', trend: '+12%', up: true, icon: Recycle, iconBg: 'bg-green-100', iconColor: 'text-green-700' },
  { label: 'Active Bins', value: '342', trend: '+5', up: true, icon: Trash2, iconBg: 'bg-green-100', iconColor: 'text-green-700' },
  { label: 'Contamination Rate', value: '8.2%', trend: '-2.1%', up: false, icon: AlertTriangle, iconBg: 'bg-saffron-100', iconColor: 'text-saffron-500' },
  { label: 'System Health', value: '98.5%', trend: 'Healthy', up: true, icon: Activity, iconBg: 'bg-green-100', iconColor: 'text-green-700' },
];

export default function AdminDashboard() {
  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
        <p className="text-sm text-muted-foreground">Real-time waste management overview</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {kpis.map((k, i) => (
          <div key={i} className="bg-card border border-border rounded-2xl p-5 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <div className={`w-10 h-10 rounded-xl ${k.iconBg} flex items-center justify-center`}>
                <k.icon className={`w-5 h-5 ${k.iconColor}`} />
              </div>
              <span className={`text-xs font-semibold rounded-full px-2 py-0.5 flex items-center gap-1 ${k.up ? 'bg-green-100 text-green-700' : 'bg-destructive/10 text-destructive'}`}>
                {k.up ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                {k.trend}
              </span>
            </div>
            <p className="text-3xl font-bold text-foreground">{k.value}</p>
            <p className="text-sm text-muted-foreground">{k.label}</p>
          </div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid lg:grid-cols-5 gap-4 mb-6">
        <div className="lg:col-span-3 bg-card border border-border rounded-2xl p-5 shadow-sm">
          <h3 className="text-sm font-bold text-foreground mb-4">Hourly Disposal Trend</h3>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={hourlyData}>
              <defs>
                <linearGradient id="greenGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2D9E68" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#2D9E68" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#E2EBE6" vertical={false} />
              <XAxis dataKey="hour" tick={{ fontSize: 11, fill: '#7A9A87' }} />
              <YAxis tick={{ fontSize: 11, fill: '#7A9A87' }} />
              <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #E2EBE6', fontSize: 12 }} />
              <Area type="monotone" dataKey="disposals" stroke="#2D9E68" strokeWidth={2} fill="url(#greenGrad)" animationDuration={1200} />
              <Area type="monotone" dataKey="avg" stroke="#F4873B" strokeWidth={1.5} strokeDasharray="5 5" fill="none" animationDuration={1200} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <div className="lg:col-span-2 bg-card border border-border rounded-2xl p-5 shadow-sm">
          <h3 className="text-sm font-bold text-foreground mb-4">Waste Distribution</h3>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={wasteDistribution} cx="50%" cy="45%" innerRadius={60} outerRadius={100} paddingAngle={3} dataKey="value" animationDuration={1000}>
                {wasteDistribution.map((entry, i) => <Cell key={i} fill={entry.color} />)}
              </Pie>
              <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
              <Tooltip contentStyle={{ borderRadius: 12, fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid lg:grid-cols-2 gap-4">
        <div className="bg-card border border-border rounded-2xl p-5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-foreground">Live Feed</h3>
            <span className="bg-green-100 text-green-700 text-[10px] rounded-full px-2 py-0.5 font-semibold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />Real-time
            </span>
          </div>
          <div className="space-y-0">
            {classifications.slice(0, 8).map(c => (
              <div key={c.id} className="flex items-center gap-3 py-3 border-b border-background last:border-0">
                <div className="w-8 h-8 rounded-lg bg-green-100 flex items-center justify-center flex-shrink-0">
                  <Recycle className="w-4 h-4 text-green-700" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground capitalize">{c.category} • {c.bin_code}</p>
                  <p className="text-[11px] text-muted-foreground">{timeAgo(c.timestamp)} • {c.confidence}% confidence</p>
                </div>
                {c.is_contamination ? (
                  <span className="bg-destructive/10 text-destructive text-[10px] rounded-full px-2 py-0.5 font-semibold flex-shrink-0">⚠ Contamination</span>
                ) : (
                  <span className="bg-green-100 text-green-700 text-[10px] rounded-full px-2 py-0.5 font-semibold flex-shrink-0">Rewarded</span>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="bg-card border border-border rounded-2xl p-5 shadow-sm">
          <h3 className="text-sm font-bold text-foreground mb-4">Bin Status</h3>
          <div className="space-y-0">
            {bins.slice(0, 5).map(b => (
              <div key={b.id} className="py-3 border-b border-background last:border-0">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-semibold font-mono text-green-700">{b.bin_code}</span>
                  <span className={`text-[10px] rounded-full px-2 py-0.5 font-semibold ${b.fill_level > 85 ? 'bg-destructive/10 text-destructive' : 'bg-green-100 text-green-700'}`}>
                    {b.fill_level > 85 ? 'Full' : 'Normal'}
                  </span>
                </div>
                <p className="text-[11px] text-muted-foreground mb-2">{b.location_name}, {b.zone}</p>
                <div className="flex items-center gap-2">
                  <div className="flex-1 h-2 bg-border rounded-full overflow-hidden">
                    <div className={`h-full rounded-full transition-all duration-500 ${b.fill_level > 85 ? 'bg-destructive' : b.fill_level > 70 ? 'bg-saffron-500' : 'bg-green-500'}`}
                      style={{ width: `${b.fill_level}%` }} />
                  </div>
                  <span className="text-[11px] text-muted-foreground w-8 text-right">{b.fill_level}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
