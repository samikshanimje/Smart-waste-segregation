import { products } from '@/lib/mock-data';
import { Plus } from 'lucide-react';

export default function AdminShop() {
  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">SwachhMart Admin</h1>
          <p className="text-sm text-muted-foreground">Manage products and redemptions</p>
        </div>
        <button className="bg-green-500 text-primary-foreground rounded-xl px-4 py-2.5 text-sm font-semibold hover:bg-green-700 transition-colors flex items-center gap-2">
          <Plus className="w-4 h-4" />Add Product
        </button>
      </div>

      <div className="bg-card border border-border rounded-2xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead><tr className="bg-background text-xs uppercase text-muted-foreground border-b border-border">
              <th className="text-left px-4 py-3 font-semibold">Product</th>
              <th className="text-left px-4 py-3 font-semibold">Category</th>
              <th className="text-left px-4 py-3 font-semibold">Price</th>
              <th className="text-left px-4 py-3 font-semibold">Stock</th>
              <th className="text-left px-4 py-3 font-semibold">Eco Impact</th>
            </tr></thead>
            <tbody>
              {products.map(p => (
                <tr key={p.id} className="border-b border-background hover:bg-background transition-colors">
                  <td className="px-4 py-3">
                    <p className="text-sm font-semibold text-foreground">{p.name}</p>
                    <p className="text-xs text-muted-foreground line-clamp-1">{p.description}</p>
                  </td>
                  <td className="px-4 py-3"><span className="bg-green-100 text-green-700 text-[10px] rounded-full px-2 py-0.5 font-semibold">{p.category}</span></td>
                  <td className="px-4 py-3 text-sm font-bold text-xpgold">🪙 {p.coin_price}</td>
                  <td className="px-4 py-3 text-sm text-foreground">{p.stock}</td>
                  <td className="px-4 py-3 text-sm text-muted-foreground">{p.eco_impact_kg}kg</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
