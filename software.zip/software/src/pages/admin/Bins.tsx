import { useState } from 'react';
import { bins } from '@/lib/mock-data';
import { Search, Plus, MapPin } from 'lucide-react';

export default function AdminBins() {
  const [search, setSearch] = useState('');
  const filtered = bins.filter(b => b.bin_code.toLowerCase().includes(search.toLowerCase()) || b.location_name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Bins</h1>
          <p className="text-sm text-muted-foreground">Manage all smart bins</p>
        </div>
        <button className="bg-green-500 text-primary-foreground rounded-xl px-4 py-2.5 text-sm font-semibold hover:bg-green-700 transition-colors flex items-center gap-2">
          <Plus className="w-4 h-4" />Add Bin
        </button>
      </div>
      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input type="text" placeholder="Search bins..." value={search} onChange={e => setSearch(e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 bg-card border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary" />
      </div>
      <div className="bg-card border border-border rounded-2xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-background text-xs uppercase text-muted-foreground border-b border-border">
                <th className="text-left px-4 py-3 font-semibold">Bin Code</th>
                <th className="text-left px-4 py-3 font-semibold">Location</th>
                <th className="text-left px-4 py-3 font-semibold">Zone</th>
                <th className="text-left px-4 py-3 font-semibold">Fill Level</th>
                <th className="text-left px-4 py-3 font-semibold">Status</th>
                <th className="text-left px-4 py-3 font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(b => (
                <tr key={b.id} className="border-b border-background hover:bg-background transition-colors">
                  <td className="px-4 py-3 font-mono font-semibold text-green-700 text-sm">{b.bin_code}</td>
                  <td className="px-4 py-3 text-sm text-foreground flex items-center gap-1.5"><MapPin className="w-3 h-3 text-muted-foreground" />{b.location_name}</td>
                  <td className="px-4 py-3 text-sm text-muted-foreground">{b.zone}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-2 bg-border rounded-full overflow-hidden">
                        <div className={`h-full rounded-full ${b.fill_level > 85 ? 'bg-destructive' : b.fill_level > 70 ? 'bg-saffron-500' : 'bg-green-500'}`} style={{ width: `${b.fill_level}%` }} />
                      </div>
                      <span className="text-xs text-muted-foreground">{b.fill_level}%</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`text-[10px] rounded-full px-2 py-0.5 font-semibold ${b.fill_level > 85 ? 'bg-destructive/10 text-destructive' : 'bg-green-100 text-green-700'}`}>
                      {b.fill_level > 85 ? 'Full' : 'Normal'}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <button className="text-xs text-info font-semibold hover:underline">View</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
