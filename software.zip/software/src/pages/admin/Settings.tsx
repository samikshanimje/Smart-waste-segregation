import { useState } from 'react';
import { toast } from 'sonner';

const pointSettings = [
  { key: 'Organic', value: 10 }, { key: 'Paper', value: 15 },
  { key: 'Plastic', value: 20 }, { key: 'Metal', value: 30 }, { key: 'E-Waste', value: 50 },
];

export default function AdminSettings() {
  const [points, setPoints] = useState(pointSettings);
  const [warning, setWarning] = useState(80);
  const [critical, setCritical] = useState(95);

  const save = () => toast.success('Settings saved successfully!');

  return (
    <div>
      <h1 className="text-2xl font-bold text-foreground mb-1">Settings</h1>
      <p className="text-sm text-muted-foreground mb-6">Configure system parameters</p>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
          <h3 className="font-bold text-foreground mb-4">Point Values</h3>
          <div className="space-y-3">
            {points.map((p, i) => (
              <div key={p.key} className="flex items-center justify-between">
                <span className="text-sm text-foreground">{p.key}</span>
                <input type="number" value={p.value} onChange={e => { const n = [...points]; n[i] = { ...p, value: +e.target.value }; setPoints(n); }}
                  className="w-20 text-right px-3 py-1.5 bg-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary" />
              </div>
            ))}
          </div>
          <button onClick={save} className="mt-4 w-full bg-green-500 text-primary-foreground rounded-xl py-2.5 text-sm font-semibold hover:bg-green-700 transition-colors">Save Point Values</button>
        </div>

        <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
          <h3 className="font-bold text-foreground mb-4">Alert Thresholds</h3>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-foreground">Warning at</label>
              <div className="flex items-center gap-2 mt-1">
                <input type="number" value={warning} onChange={e => setWarning(+e.target.value)}
                  className="w-20 px-3 py-1.5 bg-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary" />
                <span className="text-sm text-muted-foreground">%</span>
              </div>
            </div>
            <div>
              <label className="text-sm text-foreground">Critical at</label>
              <div className="flex items-center gap-2 mt-1">
                <input type="number" value={critical} onChange={e => setCritical(+e.target.value)}
                  className="w-20 px-3 py-1.5 bg-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary" />
                <span className="text-sm text-muted-foreground">%</span>
              </div>
            </div>
          </div>
          <button onClick={save} className="mt-4 w-full bg-green-500 text-primary-foreground rounded-xl py-2.5 text-sm font-semibold hover:bg-green-700 transition-colors">Save Thresholds</button>
        </div>
      </div>
    </div>
  );
}
