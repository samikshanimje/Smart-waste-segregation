import { useState } from 'react';
import { ngos } from '@/lib/mock-data';
import { CheckCircle2, XCircle } from 'lucide-react';
import { toast } from 'sonner';

export default function AdminNgos() {
  const [tab, setTab] = useState<'registrations' | 'pickups'>('registrations');
  const [localNgos, setLocalNgos] = useState(ngos);

  const approve = (id: string) => {
    setLocalNgos(prev => prev.map(n => n.id === id ? { ...n, approved: true } : n));
    toast.success('NGO approved successfully');
  };

  const pending = localNgos.filter(n => !n.approved);
  const approved = localNgos.filter(n => n.approved);

  return (
    <div>
      <h1 className="text-2xl font-bold text-foreground mb-1">NGO Management</h1>
      <p className="text-sm text-muted-foreground mb-6">Manage NGO registrations and pickups</p>

      <div className="flex gap-2 mb-6">
        <button onClick={() => setTab('registrations')} className={`rounded-xl px-4 py-2 text-sm font-semibold ${tab === 'registrations' ? 'bg-green-100 text-green-700' : 'text-muted-foreground'}`}>Registrations</button>
        <button onClick={() => setTab('pickups')} className={`rounded-xl px-4 py-2 text-sm font-semibold ${tab === 'pickups' ? 'bg-green-100 text-green-700' : 'text-muted-foreground'}`}>Pickup Requests</button>
      </div>

      {tab === 'registrations' && (
        <>
          {pending.length > 0 && (
            <div className="mb-6">
              <h3 className="text-sm font-bold text-foreground mb-3">Pending Approval</h3>
              <div className="space-y-3">
                {pending.map(n => (
                  <div key={n.id} className="bg-card border border-border rounded-2xl p-5">
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-semibold text-foreground">{n.org_name}</h4>
                        <p className="text-xs text-muted-foreground">Reg: {n.reg_number} • Contact: {n.contact_name}</p>
                        <div className="flex flex-wrap gap-1.5 mt-2">
                          {n.zones_served.map(z => <span key={z} className="bg-green-100 text-green-700 text-[10px] rounded-full px-2 py-0.5 font-semibold">{z}</span>)}
                          {n.waste_types_accepted.map(w => <span key={w} className="bg-blue-100 text-blue-500 text-[10px] rounded-full px-2 py-0.5 font-semibold">{w}</span>)}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <button onClick={() => approve(n.id)} className="bg-green-500 text-primary-foreground rounded-lg px-3 py-1.5 text-xs font-semibold flex items-center gap-1"><CheckCircle2 className="w-3 h-3" />Approve</button>
                        <button className="border border-destructive text-destructive rounded-lg px-3 py-1.5 text-xs font-semibold flex items-center gap-1"><XCircle className="w-3 h-3" />Reject</button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          <h3 className="text-sm font-bold text-foreground mb-3">Approved NGOs</h3>
          <div className="bg-card border border-border rounded-2xl shadow-sm overflow-hidden">
            <table className="w-full">
              <thead><tr className="bg-background text-xs uppercase text-muted-foreground border-b border-border">
                <th className="text-left px-4 py-3 font-semibold">NGO Name</th>
                <th className="text-left px-4 py-3 font-semibold">Zones</th>
                <th className="text-left px-4 py-3 font-semibold">Pickups</th>
                <th className="text-left px-4 py-3 font-semibold">Total kg</th>
              </tr></thead>
              <tbody>
                {approved.map(n => (
                  <tr key={n.id} className="border-b border-background hover:bg-background">
                    <td className="px-4 py-3 text-sm font-semibold text-foreground">{n.org_name}</td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">{n.zones_served.join(', ')}</td>
                    <td className="px-4 py-3 text-sm text-foreground">{n.total_pickups}</td>
                    <td className="px-4 py-3 text-sm text-foreground">{n.total_kg}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {tab === 'pickups' && (
        <div className="bg-card border border-border rounded-2xl shadow-sm p-8 text-center">
          <p className="text-muted-foreground text-sm">Pickup requests from NGOs will appear here.</p>
        </div>
      )}
    </div>
  );
}
