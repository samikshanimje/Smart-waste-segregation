import { useState } from 'react';
import { classifications, timeAgo } from '@/lib/mock-data';
import { Download } from 'lucide-react';

export default function AdminLogs() {
  const [tab, setTab] = useState<'classification' | 'access'>('classification');

  return (
    <div>
      <h1 className="text-2xl font-bold text-foreground mb-1">Logs</h1>
      <p className="text-sm text-muted-foreground mb-6">Classification and access audit trail</p>

      <div className="flex items-center justify-between mb-4">
        <div className="flex gap-2">
          <button onClick={() => setTab('classification')} className={`rounded-xl px-4 py-2 text-sm font-semibold transition-colors ${tab === 'classification' ? 'bg-green-100 text-green-700' : 'text-muted-foreground'}`}>Classification Log</button>
          <button onClick={() => setTab('access')} className={`rounded-xl px-4 py-2 text-sm font-semibold transition-colors ${tab === 'access' ? 'bg-green-100 text-green-700' : 'text-muted-foreground'}`}>Access Log</button>
        </div>
        <button className="flex items-center gap-2 border border-border rounded-xl px-4 py-2 text-sm text-muted-foreground hover:bg-card"><Download className="w-4 h-4" />Export</button>
      </div>

      {tab === 'classification' && (
        <div className="bg-card border border-border rounded-2xl shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-background text-xs uppercase text-muted-foreground border-b border-border">
                  <th className="text-left px-4 py-3 font-semibold">Time</th>
                  <th className="text-left px-4 py-3 font-semibold">Bin</th>
                  <th className="text-left px-4 py-3 font-semibold">Category</th>
                  <th className="text-left px-4 py-3 font-semibold">Confidence</th>
                  <th className="text-left px-4 py-3 font-semibold">Status</th>
                </tr>
              </thead>
              <tbody>
                {classifications.map(c => (
                  <tr key={c.id} className="border-b border-background hover:bg-background transition-colors">
                    <td className="px-4 py-3 text-xs text-muted-foreground">{timeAgo(c.timestamp)}</td>
                    <td className="px-4 py-3 text-sm font-mono font-semibold text-green-700">{c.bin_code}</td>
                    <td className="px-4 py-3"><span className="capitalize text-sm text-foreground">{c.category}</span></td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-12 h-1.5 bg-border rounded-full overflow-hidden"><div className="h-full bg-green-500 rounded-full" style={{ width: `${c.confidence}%` }} /></div>
                        <span className="text-xs text-muted-foreground">{c.confidence}%</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      {c.is_contamination ? <span className="text-xs text-destructive font-semibold">⚠ Contamination</span> : <span className="text-xs text-green-700 font-semibold">✓ Clean</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'access' && (
        <div className="bg-card border border-border rounded-2xl shadow-sm p-8 text-center">
          <p className="text-muted-foreground text-sm">Access logs will appear here when bin lock/unlock events are recorded.</p>
        </div>
      )}
    </div>
  );
}
