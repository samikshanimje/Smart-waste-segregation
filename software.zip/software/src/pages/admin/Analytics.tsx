import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, AreaChart, Area } from 'recharts';

const monthlyData = [
  { month: 'Sep', thisYear: 1200, lastYear: 900 },
  { month: 'Oct', thisYear: 1500, lastYear: 1100 },
  { month: 'Nov', thisYear: 1800, lastYear: 1300 },
  { month: 'Dec', thisYear: 2100, lastYear: 1500 },
  { month: 'Jan', thisYear: 2400, lastYear: 1800 },
  { month: 'Feb', thisYear: 2800, lastYear: 2000 },
];

const contaminationData = [
  { week: 'W1', rate: 12 }, { week: 'W2', rate: 10 }, { week: 'W3', rate: 9 },
  { week: 'W4', rate: 11 }, { week: 'W5', rate: 8 }, { week: 'W6', rate: 7 },
  { week: 'W7', rate: 6 }, { week: 'W8', rate: 8 },
];

const zoneData = [
  { zone: 'Noida', volume: 3200 }, { zone: 'Delhi', volume: 2800 },
  { zone: 'Bangalore', volume: 2400 }, { zone: 'Mumbai', volume: 2100 },
  { zone: 'Pune', volume: 1500 },
];

export default function AdminAnalytics() {
  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Analytics</h1>
          <p className="text-sm text-muted-foreground">Detailed reports and insights</p>
        </div>
        <div className="flex gap-2">
          {['Today', 'This Week', 'This Month'].map(p => (
            <button key={p} className="text-xs rounded-full px-3 py-1.5 border border-border text-muted-foreground hover:bg-card transition-colors">{p}</button>
          ))}
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <div className="bg-card border border-border rounded-2xl p-5 shadow-sm">
          <h3 className="text-sm font-bold text-foreground mb-4">Waste Diversion Rate</h3>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={monthlyData}>
              <defs>
                <linearGradient id="aGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2D9E68" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#2D9E68" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#E2EBE6" vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#7A9A87' }} />
              <YAxis tick={{ fontSize: 11, fill: '#7A9A87' }} />
              <Tooltip contentStyle={{ borderRadius: 12, fontSize: 12 }} />
              <Area type="monotone" dataKey="thisYear" stroke="#2D9E68" fill="url(#aGrad)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-card border border-border rounded-2xl p-5 shadow-sm">
          <h3 className="text-sm font-bold text-foreground mb-4">Category Comparison</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E2EBE6" vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#7A9A87' }} />
              <YAxis tick={{ fontSize: 11, fill: '#7A9A87' }} />
              <Tooltip contentStyle={{ borderRadius: 12, fontSize: 12 }} />
              <Bar dataKey="thisYear" fill="#2D9E68" radius={[4, 4, 0, 0]} />
              <Bar dataKey="lastYear" fill="#E2EBE6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-card border border-border rounded-2xl p-5 shadow-sm">
          <h3 className="text-sm font-bold text-foreground mb-4">Contamination Rate Trend</h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={contaminationData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E2EBE6" vertical={false} />
              <XAxis dataKey="week" tick={{ fontSize: 11, fill: '#7A9A87' }} />
              <YAxis tick={{ fontSize: 11, fill: '#7A9A87' }} unit="%" />
              <Tooltip contentStyle={{ borderRadius: 12, fontSize: 12 }} />
              <Line type="monotone" dataKey="rate" stroke="#F4873B" strokeWidth={2} dot={{ r: 4, fill: '#F4873B' }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-card border border-border rounded-2xl p-5 shadow-sm">
          <h3 className="text-sm font-bold text-foreground mb-4">Top Zones by Volume</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={zoneData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#E2EBE6" horizontal={false} />
              <XAxis type="number" tick={{ fontSize: 11, fill: '#7A9A87' }} />
              <YAxis type="category" dataKey="zone" tick={{ fontSize: 11, fill: '#7A9A87' }} width={80} />
              <Tooltip contentStyle={{ borderRadius: 12, fontSize: 12 }} />
              <Bar dataKey="volume" fill="#2D9E68" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
