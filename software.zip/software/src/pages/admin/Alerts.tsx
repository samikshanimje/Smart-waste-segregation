import { useState } from 'react';
import { alerts } from '@/lib/mock-data';
import { AlertTriangle, AlertCircle, Info, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';

type Tab = 'all' | 'critical' | 'warning' | 'info' | 'resolved';

const severityConfig = {
  critical: { icon: AlertTriangle, color: 'text-destructive', bg: 'bg-destructive/10', bar: 'bg-destructive' },
  warning: { icon: AlertCircle, color: 'text-saffron-500', bg: 'bg-saffron-100', bar: 'bg-saffron-500' },
  info: { icon: Info, color: 'text-info', bg: 'bg-blue-100', bar: 'bg-info' },
};

export default function AdminAlerts() {
  const [tab, setTab] = useState<Tab>('all');
  const [localAlerts, setLocalAlerts] = useState(alerts);

  const filtered = localAlerts.filter(a => {
    if (tab === 'resolved') return a.resolved;
    if (tab === 'all') return !a.resolved;
    return a.severity === tab && !a.resolved;
  });

  const resolve = (id: string) => {
    setLocalAlerts(prev => prev.map(a => a.id === id ? { ...a, resolved: true } : a));
    toast.success('Alert resolved');
  };

  const tabs: Tab[] = ['all', 'critical', 'warning', 'info', 'resolved'];

  return (
    <div>
      <h1 className="text-2xl font-bold text-foreground mb-1">Alerts</h1>
      <p className="text-sm text-muted-foreground mb-6">Monitor and manage system alerts</p>

      <div className="flex gap-2 mb-6 flex-wrap">
        {tabs.map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`rounded-full px-4 py-1.5 text-xs font-semibold capitalize transition-colors ${tab === t ? 'bg-green-700 text-primary-foreground' : 'bg-card border border-border text-muted-foreground'}`}>
            {t}
          </button>
        ))}
      </div>

      <div className="space-y-3">
        {filtered.map(a => {
          const config = severityConfig[a.severity as keyof typeof severityConfig];
          const Icon = config?.icon || Info;
          return (
            <div key={a.id} className="bg-card border border-border rounded-xl p-4 flex gap-3 items-start">
              <div className={`w-1 self-stretch rounded-full ${config?.bar || 'bg-border'}`} />
              <div className={`w-9 h-9 rounded-lg ${config?.bg} flex items-center justify-center flex-shrink-0`}>
                <Icon className={`w-4 h-4 ${config?.color}`} />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-foreground">{a.message}</p>
                <p className="text-xs text-muted-foreground mt-1">{a.bin_code} • {new Date(a.timestamp).toLocaleString()}</p>
              </div>
              {!a.resolved && (
                <button onClick={() => resolve(a.id)} className="text-xs border border-border rounded-lg px-3 py-1.5 text-muted-foreground hover:bg-background transition-colors flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />Resolve
                </button>
              )}
              {a.resolved && <span className="text-xs text-green-700 font-semibold">✓ Resolved</span>}
            </div>
          );
        })}
        {filtered.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <CheckCircle2 className="w-12 h-12 mx-auto mb-3 text-green-300" />
            <p className="font-semibold">All clear!</p>
            <p className="text-sm">No alerts in this category</p>
          </div>
        )}
      </div>
    </div>
  );
}
