import { useState } from 'react';
import { users } from '@/lib/mock-data';
import { Search } from 'lucide-react';

export default function AdminCitizens() {
  const [search, setSearch] = useState('');
  const filtered = users.filter(u => u.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div>
      <h1 className="text-2xl font-bold text-foreground mb-1">Citizens</h1>
      <p className="text-sm text-muted-foreground mb-6">Manage registered citizens</p>

      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input type="text" placeholder="Search citizens..." value={search} onChange={e => setSearch(e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 bg-card border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary" />
      </div>

      <div className="bg-card border border-border rounded-2xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead><tr className="bg-background text-xs uppercase text-muted-foreground border-b border-border">
              <th className="text-left px-4 py-3 font-semibold">Name</th>
              <th className="text-left px-4 py-3 font-semibold">Phone</th>
              <th className="text-left px-4 py-3 font-semibold">Ward</th>
              <th className="text-left px-4 py-3 font-semibold">Points</th>
              <th className="text-left px-4 py-3 font-semibold">Level</th>
              <th className="text-left px-4 py-3 font-semibold">Streak</th>
            </tr></thead>
            <tbody>
              {filtered.map(u => (
                <tr key={u.id} className="border-b border-background hover:bg-background transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-green-500 to-green-300 flex items-center justify-center text-primary-foreground text-xs font-bold">
                        {u.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <span className="text-sm font-semibold text-foreground">{u.name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-sm text-muted-foreground">{u.phone}</td>
                  <td className="px-4 py-3 text-sm text-muted-foreground">{u.ward}</td>
                  <td className="px-4 py-3 text-sm font-semibold text-xpgold">🪙 {u.points.toLocaleString()}</td>
                  <td className="px-4 py-3 text-sm text-foreground">Lv.{u.level}</td>
                  <td className="px-4 py-3 text-sm text-foreground">{u.streak > 0 ? `🔥 ${u.streak}` : '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
