import { useState } from 'react';
import { classifications, timeAgo, type Category } from '@/lib/mock-data';
import { Recycle, Download } from 'lucide-react';

const categories: (Category | 'all')[] = ['all', 'plastic', 'paper', 'metal', 'organic', 'e-waste'];

export default function AdminLiveFeed() {
  const [filter, setFilter] = useState<Category | 'all'>('all');
  const filtered = filter === 'all' ? classifications : classifications.filter(c => c.category === filter);

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Live Feed</h1>
          <p className="text-sm text-muted-foreground">Real-time classification events</p>
        </div>
        <div className="flex items-center gap-3">
          <span className="bg-green-100 text-green-700 text-xs rounded-full px-3 py-1 font-semibold flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />Real-time
          </span>
          <button className="flex items-center gap-2 border border-border rounded-xl px-4 py-2 text-sm font-medium text-muted-foreground hover:bg-card transition-colors">
            <Download className="w-4 h-4" />Export CSV
          </button>
        </div>
      </div>
      <div className="flex flex-wrap gap-2 mb-6">
        {categories.map(c => (
          <button key={c} onClick={() => setFilter(c)}
            className={`rounded-full px-4 py-1.5 text-xs font-semibold transition-colors capitalize ${filter === c ? 'bg-green-700 text-primary-foreground' : 'bg-card border border-border text-muted-foreground hover:bg-background'}`}>
            {c === 'all' ? 'All' : c}
          </button>
        ))}
      </div>
      <div className="bg-card border border-border rounded-2xl shadow-sm divide-y divide-background">
        {filtered.map(c => (
          <div key={c.id} className="flex items-center gap-3 p-4 hover:bg-background transition-colors">
            <div className="w-9 h-9 rounded-lg bg-green-100 flex items-center justify-center flex-shrink-0">
              <Recycle className="w-4 h-4 text-green-700" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-foreground capitalize">{c.category} • {c.bin_code}</p>
              <p className="text-xs text-muted-foreground">{timeAgo(c.timestamp)} • {c.confidence}% confidence</p>
            </div>
            {c.is_contamination ? (
              <span className="bg-destructive/10 text-destructive text-xs rounded-full px-2.5 py-0.5 font-semibold">⚠ Contamination</span>
            ) : (
              <span className="bg-green-100 text-green-700 text-xs rounded-full px-2.5 py-0.5 font-semibold">Rewarded +{c.points}🪙</span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
