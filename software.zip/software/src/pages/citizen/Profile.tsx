import { LogOut } from 'lucide-react';
import { Link } from 'react-router-dom';
import { getLevelInfo } from '@/lib/mock-data';

const user = { name: 'Priya Sharma', phone: '9876543210', ward: 'Ward 5', zone: 'Noida', points: 2450, level: 3, memberSince: 'Jan 2026', totalRecycled: 142 };

export default function Profile() {
  const levelInfo = getLevelInfo(user.points);
  return (
    <div>
      <div className="bg-card border border-border rounded-2xl p-6 text-center mb-6 shadow-sm">
        <div className="w-20 h-20 rounded-full bg-gradient-to-br from-green-500 to-green-300 flex items-center justify-center text-primary-foreground text-2xl font-bold mx-auto mb-3">PS</div>
        <h2 className="text-xl font-bold text-foreground">{user.name}</h2>
        <span className="inline-block bg-green-100 text-green-700 text-xs rounded-full px-3 py-1 font-semibold mt-1">{levelInfo.title}</span>
        <div className="grid grid-cols-4 gap-4 mt-6 text-center">
          {[
            { label: 'Member Since', value: user.memberSince },
            { label: 'Total Recycled', value: user.totalRecycled },
            { label: 'Lifetime Points', value: '5,200' },
            { label: 'Level', value: user.level },
          ].map((s, i) => (
            <div key={i}><p className="text-lg font-bold text-foreground">{s.value}</p><p className="text-[10px] text-muted-foreground">{s.label}</p></div>
          ))}
        </div>
      </div>

      <div className="bg-card border border-border rounded-2xl p-6 shadow-sm mb-6">
        <h3 className="font-bold text-foreground mb-4">Settings</h3>
        {['Bin Full Alerts', 'New Classification Nearby', 'Weekly Report'].map(s => (
          <div key={s} className="flex items-center justify-between py-2.5 border-b border-background last:border-0">
            <span className="text-sm text-foreground">{s}</span>
            <div className="w-10 h-6 bg-green-500 rounded-full relative cursor-pointer"><div className="w-4 h-4 bg-primary-foreground rounded-full absolute top-1 right-1" /></div>
          </div>
        ))}
      </div>

      <Link to="/login" className="flex items-center justify-center gap-2 text-destructive font-semibold text-sm py-3">
        <LogOut className="w-4 h-4" />Logout
      </Link>
    </div>
  );
}
