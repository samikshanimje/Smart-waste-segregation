import { motion } from 'framer-motion';
import { Leaf, Trophy, Zap, Recycle } from 'lucide-react';
import { classifications, bins, timeAgo, getLevelInfo, getNextLevelXP } from '@/lib/mock-data';
import { Link } from 'react-router-dom';

const user = { name: 'Priya', points: 2450, level: 3, streak: 7, itemsThisWeek: 12, wardRank: 3 };

export default function CitizenDashboard() {
  const levelInfo = getLevelInfo(user.points);
  const nextXP = getNextLevelXP(user.points);
  const progress = ((user.points - levelInfo.min) / (nextXP - levelInfo.min)) * 100;

  return (
    <div>
      {/* Welcome Banner */}
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-green-700 to-green-500 rounded-2xl p-6 text-primary-foreground mb-6">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-lg font-bold">Good morning, {user.name}! 🌿</h2>
          <span className="bg-primary-foreground/20 text-primary-foreground text-xs rounded-full px-3 py-1 font-semibold">{levelInfo.title}</span>
        </div>
        <p className="text-4xl font-bold text-xpgold mb-1">🪙 {user.points.toLocaleString()}</p>
        <p className="text-sm text-primary-foreground/70 mb-3">SwachhCoins Balance</p>
        <div className="mb-3">
          <div className="flex justify-between text-xs text-primary-foreground/70 mb-1">
            <span>{user.points} XP</span><span>{nextXP} XP to Level {user.level + 1}</span>
          </div>
          <div className="h-2.5 bg-primary-foreground/20 rounded-full overflow-hidden">
            <div className="h-full bg-xpgold rounded-full transition-all" style={{ width: `${progress}%` }} />
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm">🔥 {user.streak} Day Streak!</span>
          <div className="flex gap-1 ml-2">
            {['M','T','W','T','F','S','S'].map((d, i) => (
              <div key={i} className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold ${i < user.streak % 7 ? 'bg-primary-foreground/80 text-green-700' : i === user.streak % 7 ? 'ring-2 ring-primary-foreground animate-pulse-ring bg-primary-foreground/30' : 'bg-primary-foreground/20'}`}>{d}</div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Quick Stats */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        {[
          { icon: Leaf, label: 'Items This Week', value: user.itemsThisWeek, color: 'text-green-700 bg-green-100' },
          { icon: Trophy, label: 'Ward Rank', value: `#${user.wardRank}`, color: 'text-saffron-500 bg-saffron-100' },
          { icon: Zap, label: 'Total Points', value: user.points.toLocaleString(), color: 'text-blue-500 bg-blue-100' },
        ].map((s, i) => (
          <motion.div key={i} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}
            className="bg-card border border-border rounded-2xl p-4 hover:shadow-md hover:-translate-y-1 transition-all">
            <div className={`w-9 h-9 rounded-xl ${s.color} flex items-center justify-center mb-2`}><s.icon className="w-4 h-4" /></div>
            <p className="text-2xl font-bold text-foreground">{s.value}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
          </motion.div>
        ))}
      </div>

      {/* NFC CTA */}
      <Link to="/citizen/nfc" className="block bg-background border border-green-500 rounded-2xl p-5 mb-6 hover:shadow-md transition-shadow">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center animate-pulse-ring"><Zap className="w-6 h-6 text-green-700" /></div>
            <p className="font-semibold text-foreground">Tap your phone to the nearest bin</p>
          </div>
          <span className="bg-saffron-500 text-primary-foreground rounded-xl px-4 py-2 text-sm font-semibold">Earn Points →</span>
        </div>
      </Link>

      {/* Activity + Bins */}
      <div className="grid lg:grid-cols-2 gap-4">
        <div className="bg-card border border-border rounded-2xl p-5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-foreground">Today's Activity</h3>
            <span className="bg-green-100 text-green-700 text-[10px] rounded-full px-2 py-0.5 font-semibold flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />Real-time</span>
          </div>
          {classifications.slice(0, 5).map(c => (
            <div key={c.id} className="flex items-center gap-3 py-2.5 border-b border-background last:border-0">
              <div className="w-8 h-8 rounded-lg bg-green-100 flex items-center justify-center"><Recycle className="w-4 h-4 text-green-700" /></div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground capitalize">{c.category} • {c.bin_code}</p>
                <p className="text-[11px] text-muted-foreground">{timeAgo(c.timestamp)} • {c.confidence}%</p>
              </div>
              <span className="bg-green-100 text-green-700 text-[10px] rounded-full px-2 py-0.5 font-semibold">+{c.points}🪙</span>
            </div>
          ))}
          <Link to="/citizen/feed" className="text-xs text-info font-semibold mt-3 block">View All →</Link>
        </div>

        <div className="bg-card border border-border rounded-2xl p-5 shadow-sm">
          <h3 className="text-sm font-bold text-foreground mb-4">Nearby Bins</h3>
          {bins.slice(0, 4).map(b => (
            <div key={b.id} className="py-2.5 border-b border-background last:border-0">
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-semibold font-mono text-green-700">{b.bin_code}</span>
                <span className={`text-[10px] rounded-full px-2 py-0.5 font-semibold ${b.fill_level > 85 ? 'bg-destructive/10 text-destructive' : 'bg-green-100 text-green-700'}`}>{b.fill_level > 85 ? 'Full' : 'Normal'}</span>
              </div>
              <p className="text-[11px] text-muted-foreground mb-1.5">{b.location_name}, {b.zone}</p>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-2 bg-border rounded-full overflow-hidden"><div className={`h-full rounded-full ${b.fill_level > 85 ? 'bg-destructive' : 'bg-green-500'}`} style={{ width: `${b.fill_level}%` }} /></div>
                <span className="text-[11px] text-muted-foreground">{b.fill_level}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
