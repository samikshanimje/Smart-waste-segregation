import { useState } from 'react';
import { products } from '@/lib/mock-data';
import { toast } from 'sonner';

const categories = ['All', 'Stationery', 'Bags', 'Garden', 'Kitchen', 'Lifestyle'];
const userCoins = 2450;

export default function Shop() {
  const [cat, setCat] = useState('All');
  const filtered = cat === 'All' ? products : products.filter(p => p.category === cat);

  const redeem = (name: string, price: number) => {
    if (price <= userCoins) toast.success(`Redeemed: ${name}! 🎉`);
    else toast.error('Not enough coins');
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-xl font-bold text-foreground">SwachhMart ♻️</h1>
        <span className="bg-saffron-100 text-saffron-500 rounded-full px-3 py-1 text-xs font-bold">🪙 {userCoins.toLocaleString()}</span>
      </div>
      <div className="flex gap-2 overflow-x-auto pb-2 mb-6">
        {categories.map(c => (
          <button key={c} onClick={() => setCat(c)}
            className={`rounded-full px-4 py-1.5 text-xs font-semibold whitespace-nowrap transition-colors ${cat === c ? 'bg-green-700 text-primary-foreground' : 'bg-card border border-border text-muted-foreground'}`}>{c}</button>
        ))}
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {filtered.map(p => {
          const canAfford = p.coin_price <= userCoins;
          return (
            <div key={p.id} className="bg-card border border-border rounded-2xl overflow-hidden hover:shadow-md hover:-translate-y-1 transition-all">
              <div className="bg-green-100 h-36 flex items-center justify-center text-4xl">🌿</div>
              <div className="p-4">
                <h3 className="font-semibold text-sm text-foreground mb-1">{p.name}</h3>
                <p className="text-xs text-muted-foreground line-clamp-2 mb-3">{p.description}</p>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm font-bold text-xpgold">🪙 {p.coin_price}</span>
                  <span className={`text-[10px] rounded-full px-2 py-0.5 font-semibold ${p.stock > 10 ? 'bg-green-100 text-green-700' : 'bg-saffron-100 text-saffron-500'}`}>{p.stock > 10 ? 'In Stock' : `${p.stock} left`}</span>
                </div>
                <button onClick={() => redeem(p.name, p.coin_price)}
                  className={`w-full rounded-xl py-2 text-sm font-semibold transition-colors ${canAfford ? 'bg-green-500 text-primary-foreground hover:bg-green-700' : 'bg-background text-muted-foreground cursor-not-allowed'}`}>
                  Redeem
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
