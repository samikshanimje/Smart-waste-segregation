import CountUp from 'react-countup';
import { transactions } from '@/lib/mock-data';

export default function Wallet() {
  return (
    <div>
      <div className="bg-gradient-to-r from-saffron-500 to-warning rounded-2xl p-6 text-primary-foreground mb-6">
        <p className="text-5xl font-bold mb-1">🪙 <CountUp end={2450} duration={2} separator="," /></p>
        <p className="text-primary-foreground/80 text-sm mb-4">SwachhCoins Balance</p>
        <div className="flex gap-6 text-sm">
          <div><span className="text-primary-foreground/60">Total Earned</span><p className="font-bold">5,200</p></div>
          <div><span className="text-primary-foreground/60">Total Spent</span><p className="font-bold">2,750</p></div>
          <div><span className="text-primary-foreground/60">This Month</span><p className="font-bold">+480</p></div>
        </div>
      </div>

      <div className="bg-card border border-border rounded-2xl p-5 shadow-sm">
        <h3 className="font-bold text-foreground mb-4">Transaction History</h3>
        <div className="divide-y divide-background">
          {transactions.map(t => (
            <div key={t.id} className="flex items-center gap-3 py-3">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm ${t.type === 'earn' ? 'bg-green-100' : t.type === 'bonus' ? 'bg-saffron-100' : t.type === 'ngo-donate' ? 'bg-blue-100' : 'bg-destructive/10'}`}>
                {t.type === 'earn' ? '🟢' : t.type === 'bonus' ? '🎁' : t.type === 'ngo-donate' ? '🤝' : '🔴'}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-foreground truncate">{t.description}</p>
                <p className="text-xs text-muted-foreground">{new Date(t.timestamp).toLocaleDateString('en-IN', { month: 'short', day: 'numeric', year: 'numeric' })}</p>
              </div>
              <span className={`text-sm font-bold ${t.points > 0 ? 'text-green-700' : 'text-destructive'}`}>{t.points > 0 ? '+' : ''}{t.points}</span>
            </div>
          ))}
        </div>
        <p className="text-xs text-muted-foreground text-center mt-4">🌿 SwachhCoins never expire</p>
      </div>
    </div>
  );
}
