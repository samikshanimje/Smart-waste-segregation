import { ngos } from '@/lib/mock-data';
import { toast } from 'sonner';

export default function NgosView() {
  return (
    <div>
      <div className="bg-green-100 border-l-4 border-green-500 rounded-xl p-4 mb-6">
        <p className="text-sm text-foreground">Your recyclables were collected by <strong>GreenEarth Foundation</strong> on Feb 20 — 2.4kg diverted from landfill! 🌿</p>
      </div>
      <h1 className="text-xl font-bold text-foreground mb-4">Partner NGOs</h1>
      <div className="space-y-4">
        {ngos.filter(n => n.approved).map(n => (
          <div key={n.id} className="bg-card border border-border rounded-2xl p-5 hover:shadow-md transition-shadow">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center text-green-700 font-bold text-sm">{n.org_name[0]}</div>
              <div>
                <h3 className="font-semibold text-foreground">{n.org_name}</h3>
                <span className="bg-green-100 text-green-700 text-[10px] rounded-full px-2 py-0.5 font-semibold">✓ Approved</span>
              </div>
            </div>
            <div className="flex flex-wrap gap-1.5 mb-3">
              {n.zones_served.map(z => <span key={z} className="bg-background text-muted-foreground text-[10px] rounded-full px-2 py-0.5">{z}</span>)}
              {n.waste_types_accepted.map(w => <span key={w} className="bg-blue-100 text-blue-500 text-[10px] rounded-full px-2 py-0.5">{w}</span>)}
            </div>
            <div className="flex gap-6 text-xs text-muted-foreground mb-3">
              <span>{n.total_pickups} pickups</span><span>{n.total_kg} kg collected</span>
            </div>
            <button onClick={() => toast.success(`Donated 50 coins to ${n.org_name}! 🤝`)}
              className="border border-green-500 text-green-700 rounded-xl px-4 py-2 text-xs font-semibold hover:bg-green-100 transition-colors">Donate Points</button>
          </div>
        ))}
      </div>
    </div>
  );
}
