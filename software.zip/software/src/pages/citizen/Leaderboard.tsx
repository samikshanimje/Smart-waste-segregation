import { users } from '@/lib/mock-data';

const sorted = [...users].sort((a, b) => b.points - a.points);
const top3 = sorted.slice(0, 3);
const rest = sorted.slice(3);

export default function Leaderboard() {
  return (
    <div>
      <h1 className="text-xl font-bold text-foreground mb-6">Leaderboard</h1>

      {/* Podium */}
      <div className="flex items-end justify-center gap-3 mb-8">
        {[top3[1], top3[0], top3[2]].map((u, i) => {
          const heights = ['h-24', 'h-32', 'h-20'];
          const pos = [2, 1, 3];
          const colors = ['bg-border', 'bg-xpgold', 'bg-saffron-500/30'];
          return u ? (
            <div key={u.id} className="flex flex-col items-center">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-green-500 to-green-300 flex items-center justify-center text-primary-foreground font-bold text-sm mb-2">
                {u.name.split(' ').map(n => n[0]).join('')}
              </div>
              <p className="text-xs font-semibold text-foreground mb-1">{u.name.split(' ')[0]}</p>
              <p className="text-xs text-xpgold font-bold mb-2">🪙 {u.points.toLocaleString()}</p>
              <div className={`w-20 ${heights[i]} ${colors[i]} rounded-t-xl flex items-start justify-center pt-2`}>
                <span className="text-lg font-bold text-foreground">{pos[i] === 1 ? '👑' : `#${pos[i]}`}</span>
              </div>
            </div>
          ) : null;
        })}
      </div>

      {/* List */}
      <div className="bg-card border border-border rounded-2xl shadow-sm divide-y divide-background">
        {rest.map((u, i) => (
          <div key={u.id} className={`flex items-center gap-3 px-4 py-3 ${u.id === '1' ? 'bg-green-100 border border-green-500 rounded-xl' : ''}`}>
            <span className="text-sm font-bold text-muted-foreground w-6">{i + 4}</span>
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-green-500 to-green-300 flex items-center justify-center text-primary-foreground text-xs font-bold">
              {u.name.split(' ').map(n => n[0]).join('')}
            </div>
            <div className="flex-1">
              <p className="text-sm font-semibold text-foreground">{u.name}</p>
              <p className="text-xs text-muted-foreground">{u.ward}</p>
            </div>
            <span className="text-sm font-bold text-xpgold">🪙 {u.points.toLocaleString()}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
