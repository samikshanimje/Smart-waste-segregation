import { useState } from 'react';
import { motion } from 'framer-motion';
import { Zap } from 'lucide-react';
import { toast } from 'sonner';

export default function NfcTap() {
  const [state, setState] = useState<'idle' | 'scanning' | 'found' | 'success'>('idle');

  const startScan = () => {
    setState('scanning');
    setTimeout(() => setState('found'), 2000);
  };

  const claim = () => {
    setState('success');
    toast.success('+20 SwachhCoins earned! 🎉');
    setTimeout(() => setState('idle'), 3000);
  };

  return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
        className="bg-card border border-border rounded-2xl shadow-md p-8 text-center max-w-sm w-full">
        <div className="relative w-32 h-32 mx-auto mb-6">
          {[1,2,3].map(i => (
            <div key={i} className={`absolute inset-0 rounded-full border-2 border-green-500 opacity-30 ${state === 'scanning' ? 'animate-ripple' : ''}`} style={{ animationDelay: `${i * 0.5}s` }} />
          ))}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className={`w-16 h-16 rounded-full bg-green-100 flex items-center justify-center ${state === 'scanning' ? 'animate-pulse' : ''}`}>
              <Zap className="w-8 h-8 text-green-700" />
            </div>
          </div>
        </div>

        {state === 'idle' && (
          <>
            <h2 className="text-xl font-bold text-foreground mb-2">Earn Your Points</h2>
            <p className="text-sm text-muted-foreground mb-6">Tap your phone on any SwachhSmart bin to claim your reward points instantly.</p>
            <button onClick={startScan} className="w-full bg-saffron-500 text-primary-foreground rounded-xl py-3 font-semibold hover:opacity-90 transition-opacity">Activate NFC</button>
          </>
        )}
        {state === 'scanning' && (
          <>
            <h2 className="text-xl font-bold text-foreground mb-2">Scanning...</h2>
            <p className="text-sm text-muted-foreground">Hold your phone near the bin</p>
          </>
        )}
        {state === 'found' && (
          <>
            <h2 className="text-xl font-bold text-foreground mb-1">BIN-042</h2>
            <p className="text-sm text-muted-foreground mb-1">Sector 15, Noida</p>
            <p className="text-sm text-foreground mb-4">Last classified: <span className="font-semibold">Plastic</span> • Points: <span className="font-bold text-xpgold">+20 🪙</span></p>
            <button onClick={claim} className="w-full bg-green-500 text-primary-foreground rounded-xl py-3 font-semibold hover:bg-green-700 transition-colors">Confirm & Claim +20 Coins</button>
          </>
        )}
        {state === 'success' && (
          <div>
            <p className="text-4xl font-bold text-xpgold mb-2">+20 🪙</p>
            <p className="text-lg font-bold text-foreground">SwachhCoins Earned!</p>
          </div>
        )}
        <p className="text-xs text-muted-foreground mt-4">Can't detect NFC? <button className="text-info font-semibold">Scan QR Code instead</button></p>
      </motion.div>
    </div>
  );
}
