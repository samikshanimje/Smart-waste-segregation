import { useState } from 'react';
import { classifications, timeAgo, type Category } from '@/lib/mock-data';
import { Recycle } from 'lucide-react';

const categories: (Category | 'all')[] = ['all', 'plastic', 'paper', 'metal', 'organic', 'e-waste'];

export default function CitizenFeed() {
  const [filter, setFilter] = useState<Category | 'all'>('all');
  const filtered = filter === 'all' ? classifications : classifications.filter(c => c.category === filter);

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-xl font-bold text-foreground">Live Feed</h1>
        <span className="bg-green-100 text-green-700 text-xs rounded-full px-3 py-1 font-semibold flex items-center gap-1.5"><span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />Real-time</span>
      </div>
      <div className="flex gap-2 overflow-x-auto pb-2 mb-4">
        {categories.map(c => (
          <button key={c} onClick={() => setFilter(c)}
            className={`rounded-full px-4 py-1.5 text-xs font-semibold whitespace-nowrap transition-colors capitalize ${filter === c ? 'bg-green-700 text-primary-foreground' : 'bg-card border border-border text-muted-foreground'}`}>{c === 'all' ? 'All' : c}</button>
        ))}
      </div>
      <div className="space-y-2">
        {filtered.map(c => (
          <div key={c.id} className="bg-card border border-border rounded-xl p-4 flex items-center gap-3 hover:shadow-md hover:-translate-y-0.5 transition-all">
            <div className="w-9 h-9 rounded-lg bg-green-100 flex items-center justify-center"><Recycle className="w-4 h-4 text-green-700" /></div>
            <div className="flex-1">
              <p className="text-sm font-semibold text-foreground capitalize">{c.category} • {c.bin_code}</p>
              <p className="text-xs text-muted-foreground">{timeAgo(c.timestamp)} • {c.confidence}% confidence</p>
            </div>
            {c.is_contamination ? (
              <span className="bg-destructive/10 text-destructive text-xs rounded-full px-2.5 py-0.5 font-semibold">⚠ Contamination</span>
            ) : (
              <span className="bg-green-100 text-green-700 text-xs rounded-full px-2.5 py-0.5 font-semibold">Rewarded</span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
