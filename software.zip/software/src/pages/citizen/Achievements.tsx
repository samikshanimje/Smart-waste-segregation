import { achievements } from '@/lib/mock-data';

export default function Achievements() {
  const unlocked = achievements.filter(a => a.unlocked).length;
  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-xl font-bold text-foreground">Your Achievements</h1>
        <span className="bg-green-100 text-green-700 text-xs rounded-full px-3 py-1 font-semibold">{unlocked} / {achievements.length} Unlocked</span>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
        {achievements.map(a => (
          <div key={a.id} className={`rounded-2xl p-5 text-center transition-all ${a.unlocked ? 'bg-card border-2 border-green-500 shadow-sm hover:-translate-y-1' : 'bg-background border border-border opacity-60'}`}>
            <div className={`text-4xl mb-3 ${a.unlocked ? '' : 'grayscale'}`}>{a.emoji}</div>
            <h3 className="text-sm font-bold text-foreground mb-1">{a.title}</h3>
            {a.unlocked ? (
              <p className="text-[10px] text-muted-foreground">Unlocked {a.date}</p>
            ) : (
              <p className="text-[10px] text-muted-foreground">{a.requirement}</p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
